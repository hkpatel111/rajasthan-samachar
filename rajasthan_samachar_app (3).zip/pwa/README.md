# राजस्थान समाचार — PWA v2.2

## What's fixed in v2.2
- **SPLASH SCREEN REMOVED** — app loads directly, no more stuck splash
- **JS SYNTAX ERROR FIXED** — all JavaScript verified with Node.js --check
- **EVENT DELEGATION** — no more onclick string escaping issues
- **DISCLAIMER ADDED** — legal disclaimer with IT Act, BNS, Consumer Protection Act
- **FEEDBACK ADDED** — feedback form with complaint/suggestion/removal options

## Files
- `index.html` — complete app (CSS + HTML + JS inline, verified)
- `manifest.json` — PWA config
- `sw.js` — Service Worker v22
- `.github/workflows/deploy.yml` — GitHub Actions

## GitHub deploy
1. Create repo, add `.github/workflows/deploy.yml` (one-time)
2. Upload zip, commit
3. Settings > Pages > Source: GitHub Actions
4. URL: `https://<username>.github.io/rajasthan-samachar/`
