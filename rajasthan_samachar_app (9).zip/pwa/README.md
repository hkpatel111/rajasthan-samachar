# राजस्थान समाचार — PWA v4.5
## v4.5 Changes — DIRECT WEBSITE SCRAPING (NO RSS!)
1. **RSS completely removed**: No more rss2json.com, no more RSS feeds
2. **Direct website scraping**: News fetched by scraping actual news website pages via CORS proxy
3. **Sources**: Dainik Bhaskar, Rajasthan Patrika, Amar Ujala, NDTV Hindi, Aaj Tak, Zee News, BBC Hindi, The Hindu, Indian Express, Times of India, Economic Times
4. **How it works**: Fetches HTML page → DOMParser extracts articles → shows headlines, links, images
5. **Full article fetch**: "📖 पूरा लेख पढ़ें" fetches actual article text from source URL
6. **Auto Hindi translation**: English articles auto-translated to Hindi via Google Translate
7. **24hr weather**, panchang today green, source filter, dedup, PDF generator
## Deploy: upload zip to GitHub, Actions auto-deploy
