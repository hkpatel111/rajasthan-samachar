# राजस्थान समाचार — PWA App v2.0

## App kya hai?
Yeh ek Progressive Web App (PWA) hai — phone mein "Add to Home Screen" se install hoti hai, Play Store ki zarurat nahi. Live news, panchang, quiz, vocabulary, weather, video news, kids corner, exam prep, fact-check — sab ek app mein.

## Features (36)
1. 🔄 Live Auto-Refresh (har 5 min)
2. 📰 Live Feed + Offline reading
3. 📑 All Sections (13 categories)
4. 🎮 Interactive Quiz (15 Qs)
5. 🔤 Vocab Flashcards (25 words)
6. 🌙 Dark Mode
7. A+/A- Font Size
8. 📤 Share (WhatsApp direct)
9. 🏷️ "नया" Badge (30 min)
10. 🔔 Notifications (3 types: daily, breaking, word)
11. 📖 Word of the Day
12. ⭐ Bookmarks
13. 📍 माई इलाका (Pindawal/Sabla/Dungarpur/Aspur/Semalwara/Bichiwada)
14. 📥 Offline Download (Service Worker cache)
15. 📝 Khabar Sankshep (3-line summary)
16. 🏷️ Khabar Tags
17. 🌐 App Language (Hindi/English)
18. 📰 News Language (Hindi/English/Both)
19. 🔄 Auto-Translate toggle
20. 🔗 Source Link (clickable, har news par)
21. 🌤️ Area-specific Weather + 3-day forecast
22. 📡 26 RSS feeds (Hindi + English, 3x sources)
23. 📄 Full News Reader (expand/collapse in-app)
24. 📋 PDF Download button
25. 📅 Calendar archive (past dates)
26. 📶 Connection status indicator
27. 🌙 Hindu Panchang Calendar (moon phases, tithi, nakshatra, holidays, on-this-day history)
28. 🔍 Improved Search (recent searches, chips)
29. 🏠 Home screen customize (reorder sections)
30. 📱 App icon + splash screen
31. 🔊 आवाज़ सुनो (Hindi TTS)
32. 🎬 Video News (no autoplay, tap to play)
33. 🧒 बाल कोना (Kids Corner — safe content)
34. 📝 प्रतियोगी परीक्षा तैयारी (RPSC/REET/Patwari)
35. ✅ सत्यापन (Fact-Check)
36. 🔴 Universal: Source + Date + Verified badge on every content

## Files
- `index.html` — main app structure + CSS + config data
- `app.js` — all JavaScript functions
- `manifest.json` — PWA manifest
- `sw.js` — Service Worker (offline, notifications)
- `README.md` — yeh file
- `.github/workflows/deploy.yml` — GitHub Actions auto-deploy

## GitHub par deploy karne ka tarika

### Ek baar workflow file add karo (one-time):
1. GitHub.com par naya repository banao: `rajasthan-samachar` (Public)
2. "Add file" → "Create new file"
3. File name: `.github/workflows/deploy.yml`
4. Upar diya gaya deploy.yml code paste karo → "Commit new file"

### Zip upload karo:
1. "Add file" → "Upload files"
2. `rajasthan_samachar_app.zip` drag-drop karo
3. "Commit changes"

### Pages enable karo:
1. "Settings" → "Pages"
2. Source: "GitHub Actions" select karo

### URL milega:
```
https://<tumhari-username>.github.io/rajasthan-samachar/
```

### Phone mein install:
- Chrome mein URL kholo → "Add to Home Screen" → App ready!

## Update kaise karo?
Purani zip delete → nayi zip upload → Commit → auto-deploy!

## Tech
- HTML + CSS + vanilla JavaScript (no framework)
- PWA: manifest + Service Worker
- News: Google News RSS → rss2json.com (26 feeds)
- Weather: Open-Meteo API (area-specific lat/lon)
- Panchang: Astronomical moon phase calculation + Wikipedia "On This Day" API
- TTS: Web Speech API (Hindi)
- Video: YouTube embed (no autoplay)
- Offline: Service Worker cache + localStorage
