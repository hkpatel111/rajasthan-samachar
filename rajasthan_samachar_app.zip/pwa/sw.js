// Service Worker — राजस्थान समाचार PWA
const CACHE_NAME = 'raj-samachar-v1';
const ASSETS = ['./', './index.html', './manifest.json'];

// Install — cache core assets
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(ASSETS)));
  self.skipWaiting();
});

// Activate — clean old caches
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Fetch — cache-first for same-origin, network-first for RSS APIs
self.addEventListener('fetch', (e) => {
  const req = e.request;
  const url = new URL(req.url);

  // Don't cache API calls (RSS, weather, wiki) — always fetch fresh
  if (url.hostname !== self.location.hostname) {
    e.respondWith(fetch(req).catch(() => caches.match(req)));
    return;
  }

  // Same-origin: cache-first
  e.respondWith(
    caches.match(req).then((cached) => cached || fetch(req).then((res) => {
      const clone = res.clone();
      caches.open(CACHE_NAME).then((c) => c.put(req, clone));
      return res;
    }).catch(() => caches.match('./index.html')))
  );
});

// Periodic Background Sync — refresh news every 60 min
self.addEventListener('periodicsync', (e) => {
  if (e.tag === 'refresh-news') {
    e.waitUntil(
      self.clients.matchAll().then((clients) =>
        clients.forEach((c) => c.postMessage({ type: 'REFRESH_NEWS' }))
      )
    );
  }
});

// Push Notifications
self.addEventListener('push', (e) => {
  const data = e.data ? e.data.json() : { title: 'राजस्थान समाचार', body: 'आज का अखबार तैयार है! 📰' };
  e.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 192 192%22%3E%3Crect width=%22192%22 height=%22192%22 fill=%22%238B0000%22/%3E%3Ctext x=%2296%22 y=%22120%22 font-size=%22100%22 text-anchor=%22middle%22 fill=%22white%22%3Eरा%3C/text%3E%3C/svg%3E',
      badge: 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 96 96%22%3E%3Crect width=%2296%22 height=%2296%22 fill=%22%238B0000%22/%3E%3C/svg%3E',
      vibrate: [100, 50, 100],
      data: { url: './index.html' }
    })
  );
});

self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(clients.openWindow('./index.html'));
});
