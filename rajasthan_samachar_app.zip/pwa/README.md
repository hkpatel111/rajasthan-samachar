# राजस्थान समाचार — PWA App

## App kya hai?
Yeh ek Progressive Web App (PWA) hai — phone mein "Add to Home Screen" se install hoti hai, Play Store ki zarurat nahi. Live news, quiz, vocabulary, weather — sab ek app mein.

## Features (20)
1. 🔄 Live Auto-Refresh
2. 📰 Live Feed + Offline reading
3. 📑 All Sections (Rajasthan, Dungarpur/Wagad, National, International, Sports, etc.)
4. 🎮 Interactive Quiz — tap answer, score
5. 🔤 Vocab Flashcards — tap flip English→Hindi
6. 🌙 Dark Mode
7. A+/A- Font Size
8. 📤 Share — WhatsApp direct
9. 🏷️ "नया" Badge (30 min se kam purani news)
10. 🔔 Notifications
11. 📖 Word of the Day
12. ⭐ Bookmarks
13. 📍 माई इलाका (Pindawal/Sabla/Dungarpur)
14. 📥 Offline Download
15. 📝 Khabar Sankshep (3-line summary)
16. 🏷️ Khabar Tags
17. 🌐 App Language (Hindi/English)
18. 📰 News Language (Hindi/English/Both)
19. 🔄 Auto-Translate (English→Hindi)
20. 🔗 Source Link (clickable)

---

## 🚀 GitHub par zip upload karke deploy karna — Step by Step

### Step 1: GitHub account banao
- https://github.com par jao
- "Sign up" karo (agar account nahi hai)
- Login karo

### Step 2: Naya repository banao
- Right side upar "+" icon → "New repository"
- Repository name: `rajasthan-samachar`
- Description (optional): `Rajasthan Samachar PWA App`
- "Public" select karo (taaki GitHub Pages free chale)
- "Add a README file" ✅ tick karo
- "Create repository" dabao

### Step 3: Zip file upload karo
- Repository khuli hai
- "Add file" button → "Upload files"
- `rajasthan_samachar_app.zip` ko drag-drop ya "choose your files" se select karo
- Wait till upload completes (green tick ✅)
- Neeche "Commit changes" dabao
- Commit message: `Add app zip` (default chalne do)
- "Commit changes" dabao

### Step 4: GitHub Pages setting enable karo
- Repository mein "Settings" tab (upar) par jao
- Left side menu mein neeche scroll karo → "Pages"
- "Source" dropdown → "GitHub Actions" select karo
- Page khud-ba-khud save ho jayega

### Step 5: Workflow check karo
- Repository mein "Actions" tab par jao
- "Deploy to GitHub Pages" naam ka workflow dikhega
- Agar automatically nahi chala to "Enable workflows" ya "I understand my workflows, go ahead and enable them" dabao
- Pehla run automatically start hoga — yellow circle ⏳
- Green tick ✅ hone tak wait karo (1-2 min)

### Step 6: URL milega
- "Actions" tab mein successful run par click karo
- Neeche "github-pages" section mein URL dikhega:
```
https://<tumhari-username>.github.io/rajasthan-samachar/
```
- Ya "Settings → Pages" mein bhi URL upar dikhega

### Step 7: Phone mein install karo
- Uss URL ko phone ke Chrome/Edge mein open karo
- Browser menu (⋮) → "Add to Home Screen" ya "Install App"
- Home screen par icon aa jayega 🎉
- Ab app jaise kholta hai — full screen, icon, offline support

---

## 🔄 Future mein update kaise karo?

### Method 1: Naya zip upload
1. Naya `rajasthan_samachar_app.zip` banao
2. GitHub repository → "Add file" → "Upload files"
3. Purani zip ko delete karo (file par click → 🗑️)
4. Naya zip upload karo → "Commit changes"
5. "Actions" tab mein naya run start hoga — green ✅ hone tak wait
6. Phone mein app kholo → auto-refresh se naya content

### Method 2: Direct edit
- `index.html` par click → ✏️ edit → "Commit changes"
- 1-2 min mein app update

---

## 📂 Zip ke andar kya hai?
```
rajasthan_samachar_app.zip
├── index.html              ← Main app (sab code, 44KB)
├── manifest.json           ← PWA config (name, icon, theme)
├── sw.js                   ← Service Worker (offline, notif)
├── README.md               ← Yeh file
└── .github/
    └── workflows/
        └── deploy.yml      ← GitHub Actions (auto-deploy)
```

---

## 🛠️ Tech Stack
- **Frontend**: HTML + CSS + JavaScript (vanilla, no framework)
- **PWA**: manifest.json + Service Worker
- **News API**: Google News RSS → rss2json.com
- **Weather API**: Open-Meteo (free, no key)
- **Hosting**: GitHub Pages (free)
- **CI/CD**: GitHub Actions (auto-deploy on push)

## Alternative free hosts
- **Netlify**: https://netlify.com — zip drag-drop karo, instant URL
- **Vercel**: https://vercel.com — GitHub se auto-deploy
- **Cloudflare Pages**: https://pages.cloudflare.com

## Notes
- Auto-translate abhi simulated hai — production mein Google Translate API ya LibreTranslate lagaani hogi
- RSS feeds Google News se aate hain — kabhi-kabhi rate limit lag sakti hai
- Offline mode mein cached news dikhega
- PWA iOS Safari mein bhi work karta hai (Add to Home Screen)
- GitHub Pages free hai Public repo ke liye
