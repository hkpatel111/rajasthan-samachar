# राजस्थान समाचार — PWA App v2.1

## What changed in v2.1
- **FIXED**: Splash screen issue — all JavaScript now inline in index.html (no external app.js dependency)
- **ADDED**: Legal Disclaimer page (IT Act 2000, BNS 2023, Consumer Protection Act 2019, Copyright Act 1957)
- **ADDED**: Feedback option in menu (complaint, suggestion, content removal request, bug report)
- 36 features + disclaimer + feedback = 38 total

## Features
Live RSS (26 feeds), Weather (area-specific + 3-day forecast), Panchang calendar (moon phases), Quiz (15 Qs), Vocab flashcards, Video news, Kids corner, Exam prep, Fact-check, Bookmarks, Search, Dark mode, Font size, TTS, Share, Source links, App/News language toggle, Auto-translate, PDF download, Connection indicator, Home customize, Splash screen, Notifications (3 types)

## Files
- `index.html` — complete app (CSS + HTML + JS, all inline, 75KB)
- `manifest.json` — PWA config
- `sw.js` — Service Worker (offline cache)
- `README.md` — this file
- `.github/workflows/deploy.yml` — GitHub Actions auto-deploy

## GitHub deploy
1. Create repo `rajasthan-samachar` (Public)
2. Add file → Create new file → `.github/workflows/deploy.yml` → paste deploy.yml code → Commit
3. Upload `rajasthan_samachar_app.zip` → Commit
4. Settings → Pages → Source: "GitHub Actions"
5. URL: `https://<username>.github.io/rajasthan-samachar/`
6. Phone: Chrome → open URL → "Add to Home Screen"
