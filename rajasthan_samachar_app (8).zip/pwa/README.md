# राजस्थान समाचार — PWA v4.4
## v4.4 Changes
1. **Full article fetch**: "📖 पूरा लेख पढ़ें" button fetches the ACTUAL article from source URL via CORS proxy (allorigins.win + corsproxy.io fallback)
2. **Article text extraction**: DOMParser extracts paragraphs from article HTML, filters ads/scripts/nav
3. **Auto Hindi translation**: English articles auto-translated to Hindi via Google Translate API
4. **All v4.3 features**: 24hr weather, panchang today green, source extraction, dedup, PDF, etc.
## Deploy: upload zip to GitHub, Actions auto-deploy
