# राजस्थान समाचार — PWA v4.0
## v4.0 Changes
- 10 direct source feeds (BBC Hindi, The Hindu, Indian Express, NDTV, Amar Ujala, TOI, Zee News, Aaj Tak, Scroll, Down To Earth)
- Source filter dropdown in news section
- Video news REMOVED (unreliable)
- Panchang On This Day: Hindi first, English fallback
- Weather click: hourly forecast (12 hours)
- PDF: real generation via print window
- Archive: PDF status indicator (none/generating/ready)
- Home: PDF status box with generate button
- Quiz: Hindi/English language toggle
- Exam: 60 questions with RPSC/Patwari/REET filter
- Fact check: 15 claims with viral/govt/health filter
- Special days calendar (100+ days)
## Deploy: upload zip to GitHub, Actions auto-deploy
