# राजस्थान समाचार — PWA v4.2
## v4.2 Changes
1. **Panchang today green**: `.today` class has `!important` on background+border, applied last in class list
2. **On This Day Hindi**: Google Translate API (`translate.googleapis.com`) for English-to-Hindi translation, button works
3. **News card**: Full description shown (not truncated), no repeated heading, "पूरा पढ़ें" expand button
4. **Weather click**: Entire `.wb` box has `data-whourly`, `closest()` finds parent clicks, hint text shown
5. **PDF**: Uses `fullDesc` (full RSS description) instead of truncated `desc`
## Deploy: upload zip to GitHub, Actions auto-deploy
