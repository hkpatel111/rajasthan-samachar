// ===== राजस्थान समाचार PWA v4.1 =====
// I18N
var I18N={
hi:{home:'होम',news:'खबरें',quiz:'क्विज़',panchang:'पंचांग',more:'और',settings:'सेटिंग',refresh:'ताज़ा करो',loading:'लोड हो रहा...',todayNews:'ताज़ा खबरें',bookmarks:'मेरे सेव',noBm:'अभी कोई सेव नहीं',noNews:'खबरें उपलब्ध नहीं',source:'स्रोत',verified:'सत्यापित',summary:'संक्षेप',score:'स्कोर',correct:'सही!',wrong:'गलत',location:'मेरा इलाका',appLang:'ऐप भाषा',newsLang:'खबर भाषा',autoTranslate:'ऑटो-अनुवाद',darkMode:'डार्क मोड',on:'चालू',off:'बंद',both:'दोनों',now:'अभी',minAgo:'मिनट पहले',hrAgo:'घंटे पहले',newTag:'नया',menuTitle:'और विकल्प',offline:'ऑफ़लाइन',online:'ऑनलाइन',today:'आज',noResults:'नहीं मिला',recentSearch:'हाल की खोज',kidsCorner:'बाल कोना',examPrep:'परीक्षा तैयारी',factCheck:'सत्यापन',archive:'पुराने अंक',vocab:'शब्दावली',customize:'होम कस्टमाइज़',pdfDownload:'आज का अखबार (PDF)',pdfGenerate:'PDF बनाओ',pdfReady:'PDF तैयार! डाउनलोड करें',pdfGenerating:'PDF बन रहा है... रुकें',pdfSaved:'PDF पहले से सेव है',pdfNotSaved:'PDF सेव नहीं है',pdfCreate:'PDF बनाओ',daily:'दैनिक',wordOfDay:'रोज़ का शब्द',disclaimer:'डिस्क्लेमर',feedback:'फ़ीडबैक',allSources:'सभी स्रोत',search:'खोजें',copy:'कॉपी',copied:'कॉपी हो गया',original:'मूल देखो',translated:'अनुवाद देखो',quizLang:'भाषा',hourlyForecast:'घंटे-घंटे मौसम',weather:'मौसम',holiday:'अवकाश'},
en:{home:'Home',news:'News',quiz:'Quiz',panchang:'Panchang',more:'More',settings:'Settings',refresh:'Refresh',loading:'Loading...',todayNews:'Latest News',bookmarks:'My Saved',noBm:'No bookmarks yet',noNews:'No news available',source:'Source',verified:'Verified',summary:'Summary',score:'Score',correct:'Correct!',wrong:'Wrong',location:'My Area',appLang:'App Language',newsLang:'News Language',autoTranslate:'Auto-Translate',darkMode:'Dark Mode',on:'On',off:'Off',both:'Both',now:'now',minAgo:'min ago',hrAgo:'hr ago',newTag:'NEW',menuTitle:'More Options',offline:'Offline',online:'Online',today:'Today',noResults:'not found',recentSearch:'Recent searches',kidsCorner:'Kids Corner',examPrep:'Exam Prep',factCheck:'Fact-Check',archive:'Archive',vocab:'Vocabulary',customize:'Customize Home',pdfDownload:'Today Newspaper (PDF)',pdfGenerate:'Generate PDF',pdfReady:'PDF Ready! Download',pdfGenerating:'Generating PDF... Please wait',pdfSaved:'PDF already saved',pdfNotSaved:'PDF not saved yet',pdfCreate:'Create PDF',daily:'Daily',wordOfDay:'Word of the Day',disclaimer:'Disclaimer',feedback:'Feedback',allSources:'All Sources',search:'Search',copy:'Copy',copied:'Copied',original:'Show Original',translated:'Show Translation',quizLang:'Language',hourlyForecast:'Hourly Forecast',weather:'Weather',holiday:'Holiday'}
};
var AREAS={dungarpur:{lat:23.84,lon:73.71,hi:'डूंगरपुर',en:'Dungarpur'},pindawal:{lat:23.68,lon:73.62,hi:'पिंडावल',en:'Pindawal'},sabla:{lat:23.62,lon:73.58,hi:'साबला',en:'Sabla'},aspur:{lat:23.95,lon:73.62,hi:'आसपुर',en:'Aspur'},semalwara:{lat:23.78,lon:73.67,hi:'सीमलवाड़ा',en:'Semalwara'},bichiwada:{lat:23.72,lon:73.55,hi:'बिछीवाड़ा',en:'Bichiwada'}};
var R2J='https://api.rss2json.com/v1/api.json?rss_url=';
var WXC={0:'साफ़',1:'हल्का बादल',2:'बादल',3:'घना बादल',45:'कोहरा',48:'कोहरा',51:'हल्की बूंदाबांदी',53:'बूंदाबांदी',55:'तेज़ बूंदाबांदी',61:'हल्की बारिश',63:'बारिश',65:'तेज़ बारिश',71:'हल्की बर्फ़',73:'बर्फ़',75:'भारी बर्फ़',77:'बर्फ़ दाने',80:'हल्की बारिश',81:'बारिश',82:'तेज़ बारिश',95:'गरज',96:'गरज+ओले',99:'भारी गरज'};
var WXI={0:'☀️',1:'🌤️',2:'☁️',3:'☁️',45:'🌫️',48:'🌫️',51:'🌦️',53:'🌦️',55:'🌧️',61:'🌦️',63:'🌧️',65:'🌧️',71:'🌨️',73:'🌨️',75:'❄️',77:'🌨️',80:'🌦️',81:'🌧️',82:'⛈️',95:'⛈️',96:'⛈️',99:'⛈️'};
var SOURCE_LOGOS={'Google News':'📰','BBC Hindi':'📻','Dainik Bhaskar':'📰','Rajasthan Patrika':'📰','Amar Ujala':'📰','NDTV Hindi':'📺','The Hindu':'📰','Indian Express':'📰','Times of India':'📰','PIB':'🏛️','Zee News':'📺','Aaj Tak':'📺','The Wire':'📰','Scroll':'📰','Down To Earth':'🌱','BBC':'📻','NDTV':'📺','The Indian Express':'📰','Amar Ujala Hindi':'📰','Scroll.in':'📰','Patrika':'📰','Bhaskar':'📰','Hindustan':'📰','Live Hindustan':'📰','News18':'📺','India TV':'📺','TV9':'📺','ABP Live':'📺','NDTV India':'📺','News Nation':'📺'};
// RSS FEEDS
var FEEDS={
hi:{
rajasthan:'https://news.google.com/rss/search?q=%E0%A4%B0%E0%A4%BE%E0%A4%9C%E0%A4%B8%E0%A5%8D%E0%A4%A5%E0%A4%BE%E0%A4%A8&hl=hi-IN&gl=IN&ceid=IN:hi',
dungarpur:'https://news.google.com/rss/search?q=%E0%A4%A1%E0%A5%82%E0%A4%82%E0%A4%97%E0%A4%B0%E0%A4%AA%E0%A5%81%E0%A4%B0+OR+%E0%A4%B5%E0%A4%BE%E0%A4%97%E0%A4%A1%E0%A4%BC+OR+%E0%A4%B8%E0%A4%BE%E0%A4%AC%E0%A4%B2%E0%A4%BE+OR+%E0%A4%AA%E0%A4%BF%E0%A4%82%E0%A4%A1%E0%A4%BE%E0%A4%B5%E0%A4%B2&hl=hi-IN&gl=IN&ceid=IN:hi',
national:'https://news.google.com/rss/search?q=%E0%A4%AD%E0%A4%BE%E0%A4%B0%E0%A4%A4&hl=hi-IN&gl=IN&ceid=IN:hi',
international:'https://news.google.com/rss/search?q=%E0%A4%85%E0%A4%82%E0%A4%A4%E0%A4%B0%E0%A4%B0%E0%A4%BE%E0%A4%B7%E0%A5%8D%E0%A4%9F%E0%A5%8D%E0%A4%B0%E0%A4%BF%E0%A4%AF&hl=hi-IN&gl=IN&ceid=IN:hi',
sports:'https://news.google.com/rss/search?q=%E0%A4%96%E0%A5%87%E0%A4%B2&hl=hi-IN&gl=IN&ceid=IN:hi',
science:'https://news.google.com/rss/search?q=%E0%A4%B5%E0%A4%BF%E0%A4%9C%E0%A5%8D%E0%A4%9E%E0%A4%BE%E0%A4%A8&hl=hi-IN&gl=IN&ceid=IN:hi',
health:'https://news.google.com/rss/search?q=%E0%A4%B8%E0%A5%8D%E0%A4%B5%E0%A4%BE%E0%A4%B8%E0%A5%8D%E0%A4%A5%E0%A5%8D%E0%A4%AF&hl=hi-IN&gl=IN&ceid=IN:hi',
crime:'https://news.google.com/rss/search?q=%E0%A4%85%E0%A4%AA%E0%A4%B0%E0%A4%BE%E0%A4%A7+%E0%A4%B0%E0%A4%BE%E0%A4%9C%E0%A4%B8%E0%A5%8D%E0%A4%A5%E0%A4%BE%E0%A4%A8&hl=hi-IN&gl=IN&ceid=IN:hi',
business:'https://news.google.com/rss/search?q=%E0%A4%B5%E0%A5%8D%E0%A4%AF%E0%A4%BE%E0%A4%AA%E0%A4%BE%E0%A4%B0&hl=hi-IN&gl=IN&ceid=IN:hi',
education:'https://news.google.com/rss/search?q=%E0%A4%B6%E0%A4%BF%E0%A4%95%E0%A5%8D%E0%A4%B7%E0%A4%BE&hl=hi-IN&gl=IN&ceid=IN:hi',
agriculture:'https://news.google.com/rss/search?q=%E0%A4%95%E0%A5%83%E0%A4%B7%E0%A4%BF&hl=hi-IN&gl=IN&ceid=IN:hi',
politics:'https://news.google.com/rss/search?q=%E0%A4%B0%E0%A4%BE%E0%A4%9C%E0%A4%A8%E0%A5%80%E0%A4%A4%E0%A5%80&hl=hi-IN&gl=IN&ceid=IN:hi',
culture:'https://news.google.com/rss/search?q=%E0%A4%B8%E0%A4%82%E0%A4%B8%E0%A5%8D%E0%A4%95%E0%A5%83%E0%A4%A4%E0%A4%BF&hl=hi-IN&gl=IN&ceid=IN:hi'
},
en:{
rajasthan:'https://news.google.com/rss/search?q=Rajasthan+news&hl=en-IN&gl=IN&ceid=IN:en',
dungarpur:'https://news.google.com/rss/search?q=Dungarpur+OR+Banswara&hl=en-IN&gl=IN&ceid=IN:en',
national:'https://news.google.com/rss/search?q=India+national&hl=en-IN&gl=IN&ceid=IN:en',
international:'https://news.google.com/rss/search?q=world+news&hl=en-IN&gl=IN&ceid=IN:en',
sports:'https://news.google.com/rss/search?q=India+sports+cricket&hl=en-IN&gl=IN&ceid=IN:en',
science:'https://news.google.com/rss/search?q=science+India&hl=en-IN&gl=IN&ceid=IN:en',
health:'https://news.google.com/rss/search?q=health+India&hl=en-IN&gl=IN&ceid=IN:en',
crime:'https://news.google.com/rss/search?q=crime+Rajasthan&hl=en-IN&gl=IN&ceid=IN:en',
business:'https://news.google.com/rss/search?q=business+India&hl=en-IN&gl=IN&ceid=IN:en',
education:'https://news.google.com/rss/search?q=education+India&hl=en-IN&gl=IN&ceid=IN:en',
agriculture:'https://news.google.com/rss/search?q=agriculture+India&hl=en-IN&gl=IN&ceid=IN:en',
politics:'https://news.google.com/rss/search?q=politics+Rajasthan&hl=en-IN&gl=IN&ceid=IN:en',
culture:'https://news.google.com/rss/search?q=Culture+Rajasthan&hl=en-IN&gl=IN&ceid=IN:en'
}
};
// DIRECT SOURCE FEEDS
var DIRECT_FEEDS=[
{url:'http://feeds.bbci.co.uk/hindi/rss.xml',source:'BBC Hindi',lang:'hi',section:'national'},
{url:'https://www.thehindu.com/news/national/feeder/default.rss',source:'The Hindu',lang:'en',section:'national'},
{url:'https://indianexpress.com/feed/',source:'Indian Express',lang:'en',section:'national'},
{url:'https://khabar.ndtv.com/rss/news',source:'NDTV Hindi',lang:'hi',section:'national'},
{url:'https://www.amarujala.com/rss/breaking-news.xml',source:'Amar Ujala',lang:'hi',section:'national'},
{url:'https://timesofindia.indiatimes.com/rssfeeds/-2128936835.cms',source:'Times of India',lang:'en',section:'national'},
{url:'https://zeenews.india.com/rss/india-news.xml',source:'Zee News',lang:'hi',section:'national'},
{url:'https://www.aajtak.in/rssfeeds/?id=home',source:'Aaj Tak',lang:'hi',section:'national'},
{url:'https://scroll.in/rss',source:'Scroll',lang:'en',section:'national'},
{url:'https://www.downtoearth.org.in/rss/latest.xml',source:'Down To Earth',lang:'en',section:'science'}
];
var ALL_SOURCES=['Google News','BBC Hindi','The Hindu','Indian Express','NDTV Hindi','Amar Ujala','Times of India','Zee News','Aaj Tak','Scroll','Down To Earth','Dainik Bhaskar','Rajasthan Patrika','Patrika','Bhaskar','Hindustan','Live Hindustan','News18','India TV','TV9','ABP Live','NDTV India'];
var NEWS_SECTIONS=[{key:'rajasthan',hi:'राजस्थान',en:'Rajasthan'},{key:'dungarpur',hi:'डूंगरपुर/वागड़',en:'Dungarpur/Wagad'},{key:'national',hi:'राष्ट्रीय',en:'National'},{key:'international',hi:'अंतरराष्ट्रीय',en:'International'},{key:'sports',hi:'खेल',en:'Sports'},{key:'science',hi:'विज्ञान',en:'Science'},{key:'health',hi:'स्वास्थ्य',en:'Health'},{key:'crime',hi:'अपराध',en:'Crime'},{key:'business',hi:'व्यापार',en:'Business'},{key:'education',hi:'शिक्षा',en:'Education'},{key:'agriculture',hi:'कृषि',en:'Agriculture'},{key:'politics',hi:'राजनीती',en:'Politics'},{key:'culture',hi:'संस्कृति',en:'Culture'}];
var QUIZ=[{q:{hi:'राजस्थान की राजधानी?',en:'Capital of Rajasthan?'},o:{hi:['जयपुर','जोधपुर','उदयपुर','बीकानेर'],en:['Jaipur','Jodhpur','Udaipur','Bikaner']},a:0},{q:{hi:'डूंगरपुर किस संभाग में?',en:'Dungarpur division?'},o:{hi:['भरतपुर','उदयपुर','जयपुर','जोधपुर'],en:['Bharatpur','Udaipur','Jaipur','Jodhpur']},a:1},{q:{hi:'राजस्थान का सबसे बड़ा ज़िला?',en:'Largest district?'},o:{hi:['जैसलमेर','बाड़मेर','जोधपुर','बीकानेर'],en:['Jaisalmer','Barmer','Jodhpur','Bikaner']},a:1},{q:{hi:'माउंट आबू किस ज़िले में?',en:'Mount Abu district?'},o:{hi:['उदयपुर','सिरोही','पाली','बांसवाड़ा'],en:['Udaipur','Sirohi','Pali','Banswara']},a:1},{q:{hi:'राजस्थान का राज्य पक्षी?',en:'State bird?'},o:{hi:['मोर','तोता','सारस','बाज़'],en:['Peacock','Parrot','Crane','Falcon']},a:2},{q:{hi:'ISRO मुख्यालय?',en:'ISRO HQ?'},o:{hi:['मुंबई','बेंगलुरु','दिल्ली','चेन्नई'],en:['Mumbai','Bengaluru','Delhi','Chennai']},a:1},{q:{hi:'संविधान कब लागू?',en:'Constitution enacted?'},o:{hi:['15 अगस्त 1947','26 जनवरी 1950','26 नवंबर 1949','2 अक्टूबर 1950'],en:['15 Aug 1947','26 Jan 1950','26 Nov 1949','2 Oct 1950']},a:1},{q:{hi:'राजस्थान सबसे लंबी नदी?',en:'Longest river?'},o:{hi:['चंबल','बाणगंगा','लूनी','घग्गर'],en:['Chambal','Banganga','Luni','Ghaggar']},a:0},{q:{hi:'UNESCO मुख्यालय?',en:'UNESCO HQ?'},o:{hi:['न्यूयॉर्क','पेरिस','जिनेवा','लंदन'],en:['New York','Paris','Geneva','London']},a:1},{q:{hi:'थार रेगिस्तान?',en:'Which desert?'},o:{hi:['सहारा','थार','गोबी','कलाहारी'],en:['Sahara','Thar','Gobi','Kalahari']},a:1},{q:{hi:'राजस्थान में ज़िले?',en:'Districts count?'},o:{hi:['33','50','30','55'],en:['33','50','30','55']},a:0},{q:{hi:'पुष्कर झील ज़िला?',en:'Pushkar lake district?'},o:{hi:['जयपुर','अजमेर','उदयपुर','जोधपुर'],en:['Jaipur','Ajmer','Udaipur','Jodhpur']},a:1},{q:{hi:'राजस्थान राज्य पुष्प?',en:'State flower?'},o:{hi:['गुलाब','केवड़ा','रोहेडा','मौलश्री'],en:['Rose','Kewda','Roheda','Maulshri']},a:2},{q:{hi:'स्वाइन फ्लू वायरस?',en:'Swine flu virus?'},o:{hi:['H1N1','COVID','Dengue','Malaria'],en:['H1N1','COVID','Dengue','Malaria']},a:0},{q:{hi:'चित्तौड़गढ़ किला नदी?',en:'Chittorgarh fort river?'},o:{hi:['बनास','चंबल','गंभीरी','लूनी'],en:['Banas','Chambal','Gambhiri','Luni']},a:1}];
var VOCAB=[{e:'Account',h:'खाता'},{e:'Application',h:'आवेदन'},{e:'Available',h:'उपलब्ध'},{e:'Beneficiary',h:'लाभार्थी'},{e:'Certificate',h:'प्रमाणपत्र'},{e:'Citizen',h:'नागरिक'},{e:'Committee',h:'समिती'},{e:'Complaint',h:'शिकायत'},{e:'Deadline',h:'अंतिम तिथी'},{e:'Documents',h:'दस्तावेज़'},{e:'Eligible',h:'पात्र'},{e:'Emergency',h:'आपातकाल'},{e:'Government',h:'सरकार'},{e:'Guarantee',h:'ज़मानत'},{e:'Identity',h:'पहचान'},{e:'Income',h:'आय'},{e:'Opportunity',h:'अवसर'},{e:'Permanent',h:'स्थायी'},{e:'Procedure',h:'प्रक्रिया'},{e:'Receipt',h:'रसीद'},{e:'Registration',h:'पंजीकरण'},{e:'Scholarship',h:'छात्रवृत्ती'},{e:'Verification',h:'सत्यापन'},{e:'Welfare',h:'कल्याण'},{e:'Jurisdiction',h:'न्यायाधिकार'}];
var EXAM=[{q:'राजस्थान का गठन कब?',o:['30 मार्च 1949','15 अगस्त 1947','26 जनवरी 1950','1 नवंबर 1956'],a:0,cat:'RPSC'},{q:'लोकसभा सदस्य संख्या?',o:['545','552','543','550'],a:1,cat:'Patwari'},{q:'राजस्थान सर्वाधिक जनसंख्या वाला ज़िला?',o:['जयपुर','जोधपुर','कोटा','अलवर'],a:0,cat:'RPSC'},{q:'थार रेगिस्तान राजस्थान का कितना %?',o:['60%','65%','70%','75%'],a:1,cat:'REET'},{q:'अरावली श्रेणी लंबाई?',o:['500 किमी','692 किमी','800 किमी','1000 किमी'],a:1,cat:'Patwari'},{q:'राजस्थान का एकमात्र हिल स्टेशन?',o:['माउंट आबू','अबू रोड','कुंभलगढ़','सलूम्बर'],a:0,cat:'REET'},{q:'संविधान में अनुच्छेद?',o:['395','448','456','470'],a:1,cat:'RPSC'},{q:'राजस्थान हाई कोर्ट कहाँ?',o:['जयपुर','जोधपुर','दोनों','उदयपुर'],a:2,cat:'Patwari'},{q:'कीर्ति स्तंभ किस ने बनवाया?',o:['राणा कुंभा','राणा सांगा','बप्पा रावल','प्रताप'],a:0,cat:'REET'},{q:'बांसवाड़ा को क्या कहते हैं?',o:['चेरी शहर','बांस नगरी','सूर्य नगरी','हरित नगरी'],a:1,cat:'RPSC'},{q:'खालसा स्थापना कब?',o:['1699','1700','1705','1710'],a:0,cat:'Patwari'},{q:'राजस्थान सबसे बड़ा झील?',o:['पुष्कर','सांभर','अन्नासागर','नक्की'],a:1,cat:'REET'},{q:'स्वतंत्रता अधिनियम कब?',o:['जुलाई 1947','अगस्त 1947','जून 1947','मई 1947'],a:2,cat:'RPSC'},{q:'मानसून आगमन किस महीने?',o:['मई','जून','जुलाई','अप्रैल'],a:1,cat:'Patwari'},{q:'महाराणा प्रताप जन्म?',o:['9 मई 1540','1 जून 1540','15 अगस्त 1540','10 जुलाई 1540'],a:0,cat:'REET'},{q:'RPSC स्थापना?',o:['1949','1950','1951','1953'],a:3,cat:'RPSC'},{q:'वायु प्रदूषण कारण?',o:['वाहन','कारखाने','दोनों','पेड़'],a:2,cat:'Patwari'},{q:'राजस्थान सर्वाधिक फसल?',o:['गेहूं','बाजरा','मक्का','चना'],a:1,cat:'REET'},{q:'अशोक का पुत्र?',o:['सुदर्शन','कुणाल','तीसर','दशरथ'],a:1,cat:'RPSC'},{q:'इंदिरा गांधी नहर?',o:['राजस्थान','गुजरात','पंजाब','हरियाणा'],a:0,cat:'Patwari'},{q:'राजस्थान का क्षेत्रफल?',o:['3.4 लाख वर्ग किमी','2.4 लाख','4.4 लाख','5.4 लाख'],a:0,cat:'RPSC'},{q:'राजस्थान विधानसभा सीटें?',o:['200','195','205','210'],a:0,cat:'Patwari'},{q:'जयपुर की स्थापना किसने की?',o:['जय सिंह द्वितीय','मान सिंह','राम सिंह','प्रताप सिंह'],a:0,cat:'RPSC'},{q:'भारत का पहला उपग्रह?',o:['आर्यभट्ट','भास्कर','रोहिणी','INSAT'],a:0,cat:'Patwari'},{q:'राजस्थान का सबसे छोटा ज़िला?',o:['दौसा','जयपुर','बांसवाड़ा','प्रतापगढ़'],a:0,cat:'REET'},{q:'विश्व पर्यावरण दिवस?',o:['5 जून','5 अप्रैल','22 अप्रैल','1 मई'],a:0,cat:'Patwari'},{q:'राजस्थान का राज्य जानर?',o:['ऊंट','हिरण','बाघ','हाथी'],a:0,cat:'REET'},{q:'संविधान संशोधन किसके द्वारा?',o:['संसद','राष्ट्रपति','प्रधानमंत्री','सुप्रीम कोर्ट'],a:0,cat:'RPSC'},{q:'राजस्थान में सीमेंट उद्योग कहाँ?',o:['चित्तौड़गढ़','जयपुर','बीकानेर','कोटा'],a:0,cat:'Patwari'},{q:'राजस्थान का लोक नृत्य?',o:['घूमर','भांगड़ा','कथक','भरतनाट्यम'],a:0,cat:'REET'},{q:'भारत का सबसे बड़ा राज्य?',o:['राजस्थान','मध्य प्रदेश','महाराष्ट्र','UP'],a:0,cat:'RPSC'},{q:'राजस्थान साक्षरता दर?',o:['67%','75%','80%','60%'],a:0,cat:'Patwari'},{q:'कैमल फेस्टिवल कहाँ?',o:['बीकानेर','जैसलमेर','पुष्कर','उदयपुर'],a:0,cat:'REET'},{q:'राजस्थान का प्रथम मुख्यमंत्री?',o:['हीरालाल शास्त्री','मोहनलाल सुखाड़िया','भैरों सिंह','जय नारायण'],a:0,cat:'RPSC'},{q:'पुष्कर मेला किस लिए प्रसिद्ध?',o:['ऊंट','घोड़ा','हाथी','गाय'],a:0,cat:'Patwari'},{q:'अजमेर दरगाह किसकी?',o:['मोइनुद्दीन चिश्ती','निज़ामुद्दीन','सलीम चिश्ती','बख्तियार'],a:0,cat:'REET'},{q:'भारत का राष्ट्रीय पक्षी?',o:['मोर','तोता','कबूतर','सारस'],a:0,cat:'RPSC'},{q:'राजस्थान सबसे ऊंचा शिखर?',o:['गुरु शिखर','अबू','कुंभलगढ़','सरोही'],a:0,cat:'Patwari'},{q:'जनगणना 2011 राजस्थान जनसंख्या?',o:['6.86 करोड़','5 करोड़','7.5 करोड़','8 करोड़'],a:0,cat:'REET'},{q:'भारतीय रिज़र्व बैंक स्थापना?',o:['1935','1947','1950','1949'],a:0,cat:'RPSC'},{q:'भारत का राष्ट्रीय फल?',o:['आम','अनार','केला','सेब'],a:0,cat:'Patwari'},{q:'नाथद्वारा मंदिर किसका?',o:['श्रीनाथजी','कृष्ण','राम','शिव'],a:0,cat:'REET'},{q:'सूरतगढ़ किस ज़िले में?',o:['श्रीगंगानगर','बीकानेर','हनुमानगढ़','चूरू'],a:0,cat:'RPSC'},{q:'राजस्थान का सबसे बड़ा शहर?',o:['जयपुर','जोधपुर','कोटा','उदयपुर'],a:0,cat:'Patwari'},{q:'देश का पहला राज्य जिसने सौर ऊर्जा नीति बनाई?',o:['राजस्थान','गुजरात','मध्य प्रदेश','महाराष्ट्र'],a:0,cat:'REET'},{q:'राजस्थान में पवन ऊर्जा कहाँ?',o:['जैसलमेर','बाड़मेर','जोधपुर','बीकानेर'],a:0,cat:'RPSC'},{q:'राजस्थान में फॉस्फेट कहाँ?',o:['उदयपुर','जयपुर','जोधपुर','कोटा'],a:0,cat:'Patwari'},{q:'भारत छोड़ने का दिन?',o:['15 अगस्त 1947','26 जनवरी 1950','2 अक्टूबर 1947','1 जनवरी 1948'],a:0,cat:'REET'},{q:'राजस्थान में मक्का बाड़ी कहाँ?',o:['बांसवाड़ा','डूंगरपुर','उदयपुर','चित्तौड़गढ़'],a:0,cat:'RPSC'},{q:'माही नदी कहाँ बहती है?',o:['राजस्थान-गुजरात','मध्य प्रदेश','महाराष्ट्र','UP'],a:0,cat:'Patwari'},{q:'राजस्थान में लोहा कहाँ?',o:['भिलवाड़ा','जयपुर','कोटा','बीकानेर'],a:0,cat:'REET'},{q:'गुरु नानक जयंती कब?',o:['कार्तिक पूर्णिमा','वैशाख','माघ','फाल्गुन'],a:0,cat:'RPSC'},{q:'मकर संक्रांति कब?',o:['14 जनवरी','15 जनवरी','13 जनवरी','12 जनवरी'],a:0,cat:'Patwari'},{q:'सरदार सरोवर बांध किस नदी पर?',o:['नर्मदा','ताप्ती','तापी','माही'],a:0,cat:'REET'},{q:'राजस्थान पंचायती राज अधिनियम?',o:['1959','1960','1961','1962'],a:0,cat:'RPSC'},{q:'EWS कोटा किसके लिए?',o:['आर्थिक कमजोर','सभी','अमीर','मध्यम'],a:0,cat:'Patwari'},{q:'राजस्थान में गेहूं कहाँ?',o:['श्रीगंगानगर','बाड़मेर','जैसलमेर','बीकानेर'],a:0,cat:'RPSC'},{q:'चौपासनी किस ज़िले में?',o:['जोधपुर','जयपुर','पाली','बाड़मेर'],a:0,cat:'Patwari'}];
var KIDS=[{type:'story',title:'चींटी और कबूतर',content:'एक चींटी पानी में गिर गई। कबूतर ने पत्ता फेंककर बचाया। बाद में शिकारी से कबूतर को चींटी ने बचाया। सीख: छोटे मित्र भी बड़े काम आते हैं।',src:'लोककथा'},{type:'science',title:'आसमान नीला क्यों?',content:'सूरज की रोशनी में सात रंग होते हैं। वायुमंडल से गुजरते हुए नीला रंग सबसे ज़्यादा फैलता है (रैले प्रभाव)। इसलिए आसमान नीला दिखता है।',src:'NCERT'},{type:'history',title:'आज का इतिहास',content:'8 सितंबर 1966 को स्टार ट्रेक पहली बार टीवी पर आया। यह विज्ञान कथा धारावाहिक दुनिया भर में मशहूर हुआ।',src:'Wikipedia'},{type:'quiz',title:'बच्चों का प्रश्न',content:'पृथ्वी सूरज का चक्कर लगाती है। एक चक्कर में 365 दिन लगते हैं। इसी को एक साल कहते हैं।',src:'NCERT'},{type:'vocab',title:'आज के शब्द',content:'Rain=बारिश, Sun=सूरज, Moon=चांद, Star=तारा, Tree=पेड़, Bird=पक्षी, Water=पानी, Book=किताब',src:'Basic English'}];
var FACTS=[{claim:'WhatsApp: 500 का नोट बंद हो रहा है',verdict:'false',text:'RBI ने 500 रुपये के नोट को बंद करने की कोई घोषणा नहीं की है। यह फ़र्ज़ी अफ़वाह है।',src:'PIB Fact Check',cat:'viral'},{claim:'ऑनलाइन पासपोर्ट के लिए आधार अनिवार्य',verdict:'mixed',text:'आधार एक वैध पहचान पत्र है लेकिन अनिवार्य नहीं। अन्य पहचान पत्र भी मान्य हैं।',src:'Passport Seva',cat:'govt'},{claim:'मोबाइल से रेडिएशन होता है',verdict:'false',text:'मोबाइल फोन से होने वाला रेडिएशन बहुत कम है। WHO के अनुसार स्वास्थ्य पर कोई प्रमाणित दुष्प्रभाव नहीं।',src:'WHO',cat:'health'},{claim:'राजस्थान में इंटरनेट बंद होगा',verdict:'false',text:'राजस्थान सरकार ने इंटरनेट बंद करने की कोई घोषणा नहीं की है।',src:'PIB Fact Check',cat:'viral'},{claim:'UPI भुगतान पर टैक्स लगेगा',verdict:'mixed',text:'UPI पर कोई टैक्स नहीं, लेकिन निश्चित सीमा से ज़्यादा लेन-देन पर आयकर लागू हो सकता है।',src:'RBI',cat:'govt'},{claim:'नमक में आयोडीन से कैंसर',verdict:'false',text:'आयोडीन युक्त नमक स्वास्थ्य के लिए लाभकारी है। कैंसर का कोई प्रमाण नहीं।',src:'ICMR',cat:'health'},{claim:'रात में दही खाना नुकसानदायक',verdict:'mixed',text:'आयुर्वेद के अनुसार रात में दही ठीक है, लेकिन जुकाम वालों को बचना चाहिए।',src:'AIIMS',cat:'health'},{claim:'5G नेटवर्क से कोरोना फैलता है',verdict:'false',text:'5G रेडियो वेव से वायरस नहीं फैलता। यह पूरी तरह फ़र्ज़ी है।',src:'WHO',cat:'viral'},{claim:'वैक्सीन से नपुंसकता',verdict:'false',text:'कोविड वैक्सीन से नपुंसकता नहीं होती। यह फ़र्ज़ी दावा है।',src:'ICMR',cat:'health'},{claim:'सरकार ने सभी पुराने नोट बंद किए',verdict:'false',text:'सिर्फ़ 2000 के नोट बंद हुए। अन्य नोट वैध हैं।',src:'RBI',cat:'govt'},{claim:'ऑनलाइन लॉटरी से करोड़पति',verdict:'false',text:'अधिकांश ऑनलाइन लॉटरी फर्ज़ी होती हैं। सावधान रहें।',src:'Cyber Crime',cat:'viral'},{claim:'मधुमेह वाले चीनी खा सकते हैं',verdict:'mixed',text:'थोड़ी मात्रा में चीनी ले सकते हैं लेकिन नियंत्रण ज़रूरी है।',src:'AIIMS',cat:'health'},{claim:'EWS कोटा में सभी को आरक्षण',verdict:'false',text:'EWS कोटा सिर्फ़ आर्थिक रूप से कमज़ोर वर्ग के लिए है। आय सीमा तय है।',src:'Govt Notification',cat:'govt'},{claim:'WhatsApp पर आधार अपलोड करना सुरक्षित',verdict:'false',text:'WhatsApp पर आधार शेयर न करें। यह फर्ज़ी संदेश हो सकता है।',src:'UIDAI',cat:'viral'},{claim:'सुबह खाली पेट पानी से बीमारी दूर',verdict:'mixed',text:'सुबह पानी पीना अच्छा है लेकिन यह सभी बीमारियां दूर नहीं करता।',src:'AIIMS',cat:'health'}];

// GOVT HOLIDAYS - rashtriya avkaash (red background)
var GOVT_HOLIDAYS={'1-1':{name:'नव वर्ष',type:'govt'},'1-14':{name:'मकर संक्रांति',type:'govt'},'1-26':{name:'गणतंत्र दिवस',type:'govt'},'3-8':{name:'होली',type:'govt'},'3-21':{name:'राजस्थान दिवस',type:'govt'},'3-29':{name:'होली',type:'govt'},'4-14':{name:'अंबेडकर जयंती',type:'govt'},'5-1':{name:'मजदूर दिवस',type:'govt'},'8-15':{name:'स्वतंत्रता दिवस',type:'govt'},'9-5':{name:'शिक्षक दिवस',type:'govt'},'10-2':{name:'गांधी जयंती',type:'govt'},'10-21':{name:'दशहरा',type:'govt'},'10-22':{name:'दशहरा',type:'govt'},'11-1':{name:'राजस्थान स्थापना दिवस',type:'govt'},'12-25':{name:'क्रिसमस',type:'govt'}};
// RELIGIOUS/SPECIAL days (gold background)
var SPECIAL_DAYS={'1-5':[{n:'गुरु गोविंद सिंह जयंती',i:'🪔'}],'1-12':[{n:'राष्ट्रीय युवा दिवस',i:'🇮🇳'}],'1-23':[{n:'नेताजी सुभाष जयंती',i:'🇮🇳'}],'2-4':[{n:'विश्व कैंसर दिवस',i:'🎗️'}],'2-7':[{n:'रोज़ डे',i:'🌹'}],'2-8':[{n:'प्रपोज़ डे',i:'💝'}],'2-9':[{n:'चॉकलेट डे',i:'🍫'}],'2-10':[{n:'टेडी डे',i:'🧸'}],'2-11':[{n:'वादा डे',i:'🤝'}],'2-12':[{n:'हग डे',i:'🤗'}],'2-13':[{n:'किस डे',i:'💋'}],'2-14':[{n:'वैलेंटाइन डे',i:'❤️'}],'2-19':[{n:'छत्रपति शिवाजी जयंती',i:'🪔'}],'2-28':[{n:'राष्ट्रीय विज्ञान दिवस',i:'🔬'}],'3-3':[{n:'विश्व वन्यजीव दिवस',i:'🦁'}],'3-8':[{n:'अंतरराष्ट्रीय महिला दिवस',i:'♀️'}],'3-21':[{n:'विश्व वन दिवस',i:'🌳'}],'3-22':[{n:'विश्व जल दिवस',i:'💧'}],'3-30':[{n:'राजस्थान दिवस',i:'🇮🇳'}],'4-7':[{n:'विश्व स्वास्थ्य दिवस',i:'🏥'}],'4-22':[{n:'विश्व पृथ्वी दिवस',i:'🌍'}],'5-11':[{n:'राष्ट्रीय तकनीकी दिवस',i:'⚙️'}],'6-5':[{n:'विश्व पर्यावरण दिवस',i:'🌳'}],'6-21':[{n:'अंतरराष्ट्रीय योग दिवस',i:'🧘'}],'7-1':[{n:'राष्ट्रीय चिकित्सक दिवस',i:'👨‍⚕️'}],'8-29':[{n:'राष्ट्रीय खेल दिवस',i:'🏆'}],'9-8':[{n:'अंतरराष्ट्रीय साक्षरता दिवस',i:'📖'}],'9-14':[{n:'हिंदी दिवस',i:'अ'}],'9-21':[{n:'अंतरराष्ट्रीय शांति दिवस',i:'☮️'}],'10-8':[{n:'भारतीय वायु सेना दिवस',i:'✈️'}],'10-11':[{n:'राष्ट्रीय बालिका दिवस',i:'👧'}],'10-31':[{n:'राष्ट्रीय एकता दिवस',i:'🤝'}],'11-14':[{n:'बाल दिवस',i:'🧒'}],'12-1':[{n:'विश्व एड्स दिवस',i:'🎗️'}],'12-4':[{n:'भारतीय नौसेना दिवस',i:'⚓'}],'12-10':[{n:'मानव अधिकार दिवस',i:'✊'}],'12-22':[{n:'राष्ट्रीय गणित दिवस',i:'🔢'}]};
var TITHI_SK=['प्रतिपदा','द्वितीया','तृतीया','चतुर्थी','पंचमी','षष्ठी','सप्तमी','अष्टमी','नवमी','दशमी','एकादशी','द्वादशी','त्रयोदशी','चतुर्दशी','पूर्णिमा'];
var TITHI_KR=['प्रतिपदा','द्वितीया','तृतीया','चतुर्थी','पंचमी','षष्ठी','सप्तमी','अष्टमी','नवमी','दशमी','एकादशी','द्वादशी','त्रयोदशी','चतुर्दशी','अमावस्या'];
var NAKSHATRA=['अश्विनी','भरणी','कृत्तिका','रोहिणी','मृगशिरा','आर्द्रा','पुनर्वसू','पुष्य','आश्लेषा','मघा','पूर्वा','उत्तरा','हस्त','चित्रा','स्वाति','विशाखा','अनुराधा','ज्येष्ठा','मूला','पूर्वाषाढ़ा','उत्तराषाढ़ा','श्रवण','धनिष्ठा','शतभिषा','पूर्वा भाद्रपद','उत्तरा भाद्रपद','रेवती'];
var TAGS=['राजनीती','क्राइम','खेल','विज्ञान','स्वास्थ्य','कृषि','शिक्षा','वागड़','मेवाड़','अपराध','व्यापार','अंतरराष्ट्रीय'];

// STATE
var S={section:'home',subSection:'rajasthan',panMonth:new Date().getMonth(),panYear:new Date().getFullYear(),quizLang:localStorage.getItem('quizLang')||'hi',dark:localStorage.getItem('dark')==='true',fs:parseInt(localStorage.getItem('fs')||'16'),appLang:localStorage.getItem('appLang')||'hi',newsLang:localStorage.getItem('newsLang')||'both',autoTranslate:localStorage.getItem('autoTranslate')==='true',notifDaily:localStorage.getItem('notifDaily')==='true',notifWord:localStorage.getItem('notifWord')==='true',myArea:localStorage.getItem('myArea')||'dungarpur',cache:{},bm:JSON.parse(localStorage.getItem('bm')||'[]'),lastR:null,score:0,answered:JSON.parse(localStorage.getItem('qa')||'[]'),activeTag:null,activeSource:'all',recentSearch:JSON.parse(localStorage.getItem('rs')||'[]'),homeOrder:JSON.parse(localStorage.getItem('homeOrder')||'["rajasthan","dungarpur","national","sports","science","health"]'),expandedArticles:{},pdfStatus:{},weatherData:null,historyData:[],historyLang:'hi'};
function T(k){var l=S.appLang;return(I18N[l]&&I18N[l][k])||k;}
function showToast(m){var t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(function(){t.classList.remove('show')},3000);}
function fmtT(p){if(!p)return'';var d=new Date(p),n=new Date(),df=(n-d)/1000;if(df<60)return T('now');if(df<3600)return Math.floor(df/60)+' '+T('minAgo');if(df<86400)return Math.floor(df/3600)+' '+T('hrAgo');return d.toLocaleDateString('hi-IN');}
function getLogo(src){return SOURCE_LOGOS[src]||'📰';}

// FIX 1: Extract real source name from Google News title
// Google News title format: "Actual Title - Source Name" or "Actual Title - Source Name - Google News"
function extractSource(title,author){
  // Try to extract from title: "Title - Source"
  var parts=title.split(' - ');
  if(parts.length>=2){
    var lastPart=parts[parts.length-1].trim();
    // Remove "Google News" if it's the last part
    if(lastPart.toLowerCase().indexOf('google news')>=0&&parts.length>=3){
      lastPart=parts[parts.length-2].trim();
    }
    // Clean up source name
    if(lastPart.length>0&&lastPart.length<40){
      return lastPart;
    }
  }
  // Fallback: check author/creator field
  if(author&&author.length>0&&author.length<40){
    return author;
  }
  return 'Google News';
}
function cleanTitle(title){
  var parts=title.split(' - ');
  if(parts.length>=2){
    // Remove last part (source name) and rejoin
    parts.pop();
    // Remove "Google News" if present
    if(parts.length>=2&&parts[parts.length-1].trim().toLowerCase().indexOf('google news')>=0){
      parts.pop();
    }
    return parts.join(' - ').trim();
  }
  return title;
}

// MOON
function getMoonPhase(date){var synodic=29.530588853;var known=new Date(Date.UTC(2000,0,6,18,14,0));var diff=(date.getTime()-known.getTime())/86400000;var phase=((diff%synodic)+synodic)%synodic/synodic;return phase;}
function moonSVG(phase){var r=13,dark='#222',light='#f5f0c0';if(phase<0.02||phase>0.98)return '<svg width="28" height="28" viewBox="0 0 32 32"><circle cx="16" cy="16" r="'+r+'" fill="'+dark+'" stroke="#666" stroke-width="0.5"/></svg>';if(Math.abs(phase-0.5)<0.02)return '<svg width="28" height="28" viewBox="0 0 32 32"><circle cx="16" cy="16" r="'+r+'" fill="'+light+'" stroke="#aaa" stroke-width="0.5"/></svg>';var waxing=phase<0.5;var frac=waxing?phase*2:(1-phase)*2;var rx=r*Math.abs(1-2*frac);var path;if(waxing){if(frac<0.5){path='M 16 3 A '+r+' '+r+' 0 0 1 16 29 A '+rx+' '+r+' 0 0 0 16 3';}else{path='M 16 3 A '+r+' '+r+' 0 0 1 16 29 A '+rx+' '+r+' 0 0 1 16 3';}}else{if(frac<0.5){path='M 16 3 A '+r+' '+r+' 0 0 0 16 29 A '+rx+' '+r+' 0 0 1 16 3';}else{path='M 16 3 A '+r+' '+r+' 0 0 0 16 29 A '+rx+' '+r+' 0 0 0 16 3';}}return '<svg width="28" height="28" viewBox="0 0 32 32"><circle cx="16" cy="16" r="'+r+'" fill="'+dark+'" stroke="#666" stroke-width="0.5"/><path d="'+path+'" fill="'+light+'"/></svg>';}
function getTithi(phase){var tn=Math.floor(phase*30);var pk=tn<15?'shukla':'krishna';var idx=tn<15?tn:tn-15;var nm=pk==='shukla'?TITHI_SK[idx]:TITHI_KR[idx];return{name:nm,paksha:pk};}
function getNakshatra(date){return NAKSHATRA[Math.floor((date.getTime()/86400000)%27)];}

// RSS - Google News with source extraction
function fetchRSSByLang(lang,key){var ck=lang+'_'+key;var fu=FEEDS[lang]&&FEEDS[lang][key]?FEEDS[lang][key]:'';if(!fu)return Promise.resolve([]);return fetch(R2J+encodeURIComponent(fu)).then(function(r){return r.json()}).then(function(d){if(d.status==='ok'){var items=d.items.map(function(i){
  // FIX 1: Extract real source from title
  var realSource=extractSource(i.title||'',i.author||i.creator||'');
  var cleanT=cleanTitle(i.title||'');
  var desc=(i.description||'').replace(/<[^>]*>/g,'');
  return{title:cleanT,desc:desc.substring(0,200),fullDesc:desc,link:i.link,pubDate:i.pubDate,source:realSource,lang:lang,logo:getLogo(realSource),thumb:i.thumbnail||''};
});S.cache[ck]=items;return items;}return S.cache[ck]||[];}).catch(function(){return S.cache[ck]||[];});}
// DIRECT SOURCE FEEDS
function fetchDirectFeed(feed){var ck=feed.lang+'_'+feed.section;if(!S.cache[ck])S.cache[ck]=[];return fetch(R2J+encodeURIComponent(feed.url)).then(function(r){return r.json()}).then(function(d){if(d.status==='ok'){var items=d.items.map(function(i){var desc=(i.description||'').replace(/<[^>]*>/g,'');return{title:i.title,desc:desc.substring(0,200),fullDesc:desc,link:i.link,pubDate:i.pubDate,source:feed.source,lang:feed.lang,logo:getLogo(feed.source),thumb:i.thumbnail||''};});S.cache[ck]=S.cache[ck].concat(items);return items;}return[];}).catch(function(){return[];});}
function loadAll(){var langs=S.newsLang==='both'?['hi','en']:[S.newsLang==='hi'?'hi':'en'];var keys=Object.keys(FEEDS.hi);var promises=[];for(var i=0;i<langs.length;i++){for(var j=0;j<keys.length;j++){promises.push(fetchRSSByLang(langs[i],keys[j]));}}for(var k=0;k<DIRECT_FEEDS.length;k++){var df=DIRECT_FEEDS[k];var langOk=S.newsLang==='both'||S.newsLang===df.lang;if(langOk)promises.push(fetchDirectFeed(df));}return Promise.all(promises).then(function(){S.lastR=new Date();if(S.section==='home')renderHome();if(S.section==='news')renderNews(S.subSection||'rajasthan');showToast('✅ '+T('refresh'));}).catch(function(){});}

// WEATHER
function fetchWeather(){var area=AREAS[S.myArea]||AREAS.dungarpur;var url='https://api.open-meteo.com/v1/forecast?latitude='+area.lat+'&longitude='+area.lon+'&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min&hourly=temperature_2m,weather_code,relative_humidity_2m&timezone=Asia/Kolkata&forecast_days=4';return fetch(url).then(function(r){return r.json()}).then(function(d){S.weatherData=d;var w=d.current;var c=WXC[w.weather_code]||'साफ़';var icon=WXI[w.weather_code]||'☀️';var an=S.appLang==='hi'?area.hi:area.en;var ms=['जन','फर','मार्च','अप्रैल','मई','जून','जुलाई','अग','सित','अक्टू','नव','दिस'];var fcHTML='';if(d.daily){for(var i=0;i<Math.min(4,d.daily.time.length);i++){var dt=new Date(d.daily.time[i]);var label=i===0?T('today'):(dt.getDate()+' '+ms[dt.getMonth()]);var wc=d.daily.weather_code[i];fcHTML+='<div class="wb-day" data-wday="'+i+'"><div class="wb-day-date">'+label+'</div><div class="wb-day-icon">'+(WXI[wc]||'☀️')+'</div><div class="wb-day-temp">'+Math.round(d.daily.temperature_2m_max[i])+'° / '+Math.round(d.daily.temperature_2m_min[i])+'°</div></div>';}}var box=document.getElementById('wBox');if(box)box.innerHTML='<div class="wb-row" data-whourly="1"><div><div class="wb-city">'+icon+' '+an+' 📍</div><div class="wb-desc">'+c+' • 💧 '+w.relative_humidity_2m+'% • 💨 '+w.wind_speed_10m+'km/h</div></div><div class="wb-temp">'+Math.round(w.temperature_2m)+'°C</div></div><div class="wb-forecast">'+fcHTML+'</div>';}).catch(function(){});}

// FIX 5: Weather hourly forecast - properly replaces content
function showHourlyForecast(dayIdx){
  if(!S.weatherData||!S.weatherData.hourly){showToast('⚠️ मौसम डेटा उपलब्ध नहीं');return;}
  var h=S.weatherData.hourly;
  var now=new Date();
  var startHr=dayIdx===0?now.getHours():0;
  var endHr=dayIdx===0?Math.min(now.getHours()+12,24):Math.min(24,24);
  var area=AREAS[S.myArea]||AREAS.dungarpur;
  var an=S.appLang==='hi'?area.hi:area.en;
  var dayDate=new Date(S.weatherData.daily.time[dayIdx]);
  var ms=['जन','फर','मार्च','अप्रैल','मई','जून','जुलाई','अग','सित','अक्टू','नव','दिस'];
  var dn=['रवि','सोम','मंगल','बुध','गुरु','शुक्र','शनि'];
  var html='<div class="rfr-bar"><button class="rfr-btn" onclick="go(\'home\')">⬅️ वापस</button><span class="rfr-time">🌤️ '+T('hourlyForecast')+'</span></div>';
  html+='<div class="s-title">🌤️ '+dn[dayDate.getDay()]+', '+dayDate.getDate()+' '+ms[dayDate.getMonth()]+' — '+an+'</div>';
  html+='<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:5px">';
  var baseIdx=dayIdx*24;
  var count=0;
  for(var hr=startHr;hr<endHr&&count<12;hr++){
    var idx=baseIdx+hr;
    if(idx>=h.temperature_2m.length)break;
    var temp=Math.round(h.temperature_2m[idx]);
    var wc=h.weather_code[idx];
    var icon=WXI[wc]||'☀️';
    var desc=WXC[wc]||'साफ़';
    var hum=h.relative_humidity_2m[idx];
    html+='<div class="wb-day" style="min-width:60px">';
    html+='<div class="wb-day-date">'+String(hr).padStart(2,'0')+':00</div>';
    html+='<div class="wb-day-icon" style="font-size:22px">'+icon+'</div>';
    html+='<div class="wb-day-temp">'+temp+'°C</div>';
    html+='<div style="font-size:9px;color:var(--muted)">'+desc+'</div>';
    html+='<div style="font-size:9px;color:var(--muted)">💧 '+hum+'%</div>';
    html+='</div>';
    count++;
  }
  html+='</div>';
  html+='<div style="margin-top:10px;font-size:12px;color:var(--muted);text-align:center">⏰ '+count+' घंटे का forecast • ✅ '+T('verified')+'</div>';
  document.getElementById('content').innerHTML=html;
  window.scrollTo(0,0);
}

// TTS
function speak(text){if(!('speechSynthesis'in window)){showToast('TTS उपलब्ध नहीं');return;}stopTTS();var u=new SpeechSynthesisUtterance(text);u.lang='hi-IN';u.rate=1;u.onend=function(){stopTTS();};u.onerror=function(){stopTTS();};document.getElementById('ttsBar').classList.add('show');speechSynthesis.speak(u);}
function stopTTS(){if('speechSynthesis'in window)speechSynthesis.cancel();document.getElementById('ttsBar').classList.remove('show');}

// CONNECTION
function updateConn(){var dot=document.getElementById('connDot');var txt=document.getElementById('connText');if(navigator.onLine){dot.className='conn-dot on';txt.textContent=T('online');}else{dot.className='conn-dot off';txt.textContent=T('offline');}}
window.addEventListener('online',function(){updateConn();loadAll();});
window.addEventListener('offline',function(){updateConn();showToast('📶 '+T('offline'));});

// NEWS DATA STORE
var newsData={};
function storeNews(n){var id=Math.abs(n.title.split('').reduce(function(a,b){a=((a<<5)-a)+b.charCodeAt(0);return a&a;},0));newsData[id]=n;return id;}

// NEWS CARD
function ncHTML(n){var id=storeNews(n);var marked=S.bm.some(function(b){return b.title===n.title;});var age=(Date.now()-new Date(n.pubDate))/1000;var isNew=age<1800;var lt=n.lang==='en'?'en':'hi';var flag=n.lang==='en'?'🇬🇧':'🇮🇳';var tnNote=(n.lang==='en'&&S.autoTranslate)?' (अनुवाद)':'';var tags=TAGS.filter(function(t){return(n.title+n.desc).indexOf(t)>=0;}).slice(0,2);var tagHTML=tags.map(function(t){return '<span class="nc-tag '+lt+'" data-ftag="'+t+'">'+t+'</span>';}).join('');var ds=new Date(n.pubDate).toLocaleDateString('hi-IN');var ex=S.expandedArticles[id]?' show':'';var thumbHTML=n.thumb?'<img src="'+n.thumb+'" style="width:100%;height:120px;object-fit:cover;border-radius:6px;margin-bottom:6px" alt="">':'';return '<div class="nc" data-nid="'+id+'"><div class="nc-title">'+n.title+(isNew?'<span class="nc-new">'+T('newTag')+'</span>':'')+'<span class="nc-bm'+(marked?' on':'')+'" data-bm="'+id+'">⭐</span><span class="nc-share" data-share="'+id+'">📤</span><span class="nc-tts" data-tts="'+id+'">🔊</span><span class="nc-copy" data-copy="'+id+'">📋</span></div>'+thumbHTML+'<div class="nc-desc">'+n.desc+'... <span class="nc-sum" data-sum="'+id+'">📝 '+T('summary')+'</span></div><div class="nc-full'+ex+'" id="full'+id+'">'+(n.fullDesc||n.desc)+'</div><div><span class="nc-tag '+lt+'">'+flag+'</span>'+tagHTML+'</div><div class="nc-meta"><span class="nc-src" data-src="'+id+'">'+getLogo(n.source)+' '+T('source')+': '+n.source+tnNote+'</span> • <span>'+ds+'</span> • <span class="nc-verified">✅ '+T('verified')+'</span></div><div class="nc-time">'+fmtT(n.pubDate)+'</div></div>';}
function togBM(el,id){var n=newsData[id];if(!n)return;var i=S.bm.findIndex(function(b){return b.title===n.title;});if(i>=0){S.bm.splice(i,1);el.classList.remove('on');}else{S.bm.push({title:n.title,link:n.link,date:new Date().toISOString()});el.classList.add('on');}localStorage.setItem('bm',JSON.stringify(S.bm));}
function toggleExpand(id){if(S.expandedArticles[id]){delete S.expandedArticles[id];}else{S.expandedArticles[id]=true;}var el=document.getElementById('full'+id);if(el)el.classList.toggle('show');}
function shareArt(id){var n=newsData[id];if(!n)return;var waUrl='https://wa.me/?text='+encodeURIComponent(n.title+'\n\n'+n.link);if(navigator.share){navigator.share({title:n.title,text:n.title,url:n.link}).catch(function(){});}else{window.open(waUrl,'_blank');}}
function copyNews(id){var n=newsData[id];if(!n)return;var text=n.title+'\n\n'+n.desc+'...\n\n'+T('source')+': '+n.source+'\n'+n.link;if(navigator.clipboard){navigator.clipboard.writeText(text).then(function(){showToast('📋 '+T('copied'));});}else{showToast('📋 '+T('copied'));}}
function showSummary(el,id){var n=newsData[id];if(!n)return;var sentences=n.desc.split(/।|\./).filter(function(s){return s.trim().length>5;});var summary=sentences.slice(0,2).join('. ')+'.';el.textContent=summary;showToast('📝 '+T('summary'));}
function filterTag(t){S.activeTag=t;if(S.section==='news')renderNews(S.subSection||'rajasthan');else go('news');}
function clearTag(){S.activeTag=null;if(S.section==='news')renderNews(S.subSection||'rajasthan');}

// FIX 4: PDF - generates a proper newspaper-style HTML page in new window
function generatePDF(dateKey){
  showToast('⏳ '+T('pdfGenerating'));
  S.pdfStatus[dateKey]='generating';
  updatePDFStatus();
  setTimeout(function(){
    var allNews=[];
    Object.keys(S.cache).forEach(function(k){allNews.push.apply(allNews,S.cache[k]);});
    allNews.sort(function(a,b){return new Date(b.pubDate)-new Date(a.pubDate);});
    var area=AREAS[S.myArea]||AREAS.dungarpur;
    var w=window.open('','_blank');
    if(!w){showToast('⚠️ Popup block अनलॉक करें');S.pdfStatus[dateKey]='none';updatePDFStatus();return;}
    var html='<!DOCTYPE html><html lang="hi"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
    html+='<title>राजस्थान समाचार — '+dateKey+'</title>';
    html+='<style>';
    html+='@page{size:A4 portrait;margin:12mm 10mm}';
    html+='body{font-family:Noto Sans Devanagari,Mangal,sans-serif;font-size:11px;line-height:1.5;color:#1a1a1a;background:#fff}';
    html+='.np-header{text-align:center;border-bottom:3px double #8B0000;padding-bottom:6px;margin-bottom:10px}';
    html+='.np-title{font-size:28px;font-weight:900;color:#8B0000;letter-spacing:2px}';
    html+='.np-subtitle{font-size:11px;color:#666;margin-top:3px}';
    html+='.np-section{margin-top:12px;border-top:2px solid #8B0000;padding-top:5px}';
    html+='.np-section-title{font-size:16px;font-weight:800;color:#8B0000;margin-bottom:5px;text-transform:uppercase}';
    html+='.np-article{border-bottom:1px dashed #ccc;padding:6px 0;margin:3px 0}';
    html+='.np-article-title{font-size:13px;font-weight:700}';
    html+='.np-article-desc{font-size:11px;color:#444;margin-top:2px}';
    html+='.np-article-src{font-size:9px;color:#888;margin-top:2px}';
    html+='.np-article-src a{color:#8B0000;text-decoration:none}';
    html+='.np-two-col{column-count:2;column-gap:12px}';
    html+='.np-box{border:1px solid #ccc;padding:6px;border-radius:4px;margin:3px 0}';
    html+='.np-quiz-q{font-size:11px;margin:3px 0;padding:3px;border-left:3px solid #1565c0}';
    html+='.np-fact{font-size:11px;margin:3px 0;padding:3px;border-left:3px solid #c62828}';
    html+='.np-vocab{display:inline-block;width:48%;font-size:10px;margin:1px}';
    html+='.np-footer{text-align:center;margin-top:15px;font-size:9px;color:#999;border-top:1px solid #ccc;padding-top:5px}';
    html+='@media print{body{font-size:10pt}.no-print{display:none}}';
    html+='</style></head><body>';
    // Header
    html+='<div class="np-header"><div class="np-title">राजस्थान समाचार</div>';
    html+='<div class="np-subtitle">'+dateKey+' • '+area.hi+' (राजस्थान) • दैनिक समाचार पत्र</div></div>';
    // Top News
    var topNews=allNews.slice(0,15);
    html+='<div class="np-section"><div class="np-section-title">📰 ताज़ा खबरें (Top 15)</div>';
    topNews.forEach(function(n){
      html+='<div class="np-article"><div class="np-article-title">'+n.title+'</div>';
      html+='<div class="np-article-desc">'+n.desc+'</div>';
      html+='<div class="np-article-src">स्रोत: <a href="'+n.link+'">'+n.source+'</a> • '+new Date(n.pubDate).toLocaleDateString('hi-IN')+' • ✅ सत्यापित</div></div>';
    });
    html+='</div>';
    // Regional news
    var regionalNews=allNews.filter(function(n){return n.source.indexOf('Bhaskar')>=0||n.source.indexOf('Patrika')>=0||n.title.indexOf('राजस्थान')>=0||n.title.indexOf('डूंगरपुर')>=0;}).slice(0,8);
    if(regionalNews.length){
      html+='<div class="np-section"><div class="np-section-title">🏛️ राजस्थान / वागड़ / डूंगरपुर</div>';
      regionalNews.forEach(function(n){
        html+='<div class="np-article"><div class="np-article-title">'+n.title+'</div>';
        html+='<div class="np-article-desc">'+n.desc+'</div>';
        html+='<div class="np-article-src">स्रोत: <a href="'+n.link+'">'+n.source+'</a></div></div>';
      });
      html+='</div>';
    }
    // Sports
    var sportsNews=allNews.filter(function(n){return n.title.indexOf('खेल')>=0||n.title.indexOf('क्रिकेट')>=0||n.title.indexOf('मैच')>=0||n.desc.indexOf('खेल')>=0;}).slice(0,5);
    if(sportsNews.length){
      html+='<div class="np-section"><div class="np-section-title">🏆 खेल</div>';
      sportsNews.forEach(function(n){
        html+='<div class="np-article"><div class="np-article-title">'+n.title+'</div>';
        html+='<div class="np-article-desc">'+n.desc+'</div>';
        html+='<div class="np-article-src">स्रोत: <a href="'+n.link+'">'+n.source+'</a></div></div>';
      });
      html+='</div>';
    }
    // Quiz section
    html+='<div class="np-section"><div class="np-section-title">📝 सामान्य ज्ञान प्रश्नोत्तरी (15 प्रश्न)</div>';
    QUIZ.forEach(function(q,i){
      html+='<div class="np-quiz-q"><b>Q'+(i+1)+':</b> '+q.q.hi+' <b>उत्तर:</b> '+q.o.hi[q.a]+'</div>';
    });
    html+='</div>';
    // Exam Prep
    html+='<div class="np-section"><div class="np-section-title">📚 परीक्षा तैयारी (राजस्थान GK)</div>';
    EXAM.slice(0,20).forEach(function(q,i){
      html+='<div class="np-quiz-q"><b>Q'+(i+1)+':</b> '+q.q+' <b>उत्तर:</b> '+q.o[q.a]+' ['+q.cat+']</div>';
    });
    html+='</div>';
    // Fact Check
    html+='<div class="np-section"><div class="np-section-title">✅ सत्यापन — फ़र्ज़ी खबरें</div>';
    FACTS.forEach(function(f){
      var v=f.verdict==='true'?'✅ सच':f.verdict==='false'?'❌ फ़र्ज़ी':'⚠️ अधूरा';
      html+='<div class="np-fact"><b>दावा:</b> '+f.claim+'<br><b>नतीजा:</b> '+v+' — '+f.text+' <i>(' +f.src+')</i></div>';
    });
    html+='</div>';
    // Vocabulary
    html+='<div class="np-section"><div class="np-section-title">🔤 आज की शब्दावली</div><div class="np-box">';
    VOCAB.forEach(function(v){html+='<span class="np-vocab"><b>'+v.e+'</b> = '+v.h+'</span>';});
    html+='</div></div>';
    // Kids Corner
    html+='<div class="np-section"><div class="np-section-title">🧒 बाल कोना</div>';
    KIDS.forEach(function(k){
      html+='<div class="np-box"><b>'+k.title+'</b><br>'+k.content+'<br><i>स्रोत: '+k.src+'</i></div>';
    });
    html+='</div>';
    // Footer
    html+='<div class="np-footer">राजस्थान समाचार • '+dateKey+' • यह शैक्षिक उद्देश्य हेतु तैयार किया गया है • सभी समाचार अपने-अपने स्रोत के अधीन हैं • ✅ सत्यापित</div>';
    html+='<div style="text-align:center;margin-top:10px" class="no-print"><button onclick="window.print()" style="padding:12px 30px;font-size:16px;background:#8B0000;color:#fff;border:none;border-radius:8px;cursor:pointer">🖨️ PDF के रूप में सेव करें (Save as PDF)</button></div>';
    html+='</body></html>';
    w.document.open();
    w.document.write(html);
    w.document.close();
    S.pdfStatus[dateKey]='ready';
    updatePDFStatus();
    showToast('✅ '+T('pdfReady'));
  },1500);
}
function downloadPDF(){var today=new Date();var dk=today.getFullYear()+'-'+String(today.getMonth()+1).padStart(2,'0')+'-'+String(today.getDate()).padStart(2,'0');generatePDF(dk);}
function updatePDFStatus(){var today=new Date();var dk=today.getFullYear()+'-'+String(today.getMonth()+1).padStart(2,'0')+'-'+String(today.getDate()).padStart(2,'0');var status=S.pdfStatus[dk]||'none';var txt=document.getElementById('pdfStatusTxt');if(txt){txt.textContent=status==='ready'?'✅ '+T('pdfReady'):status==='generating'?'⏳ '+T('pdfGenerating'):T('pdfNotSaved');}}

// EVENT DELEGATION - fixed weather click
document.addEventListener('click',function(e){
  var el=e.target;
  if(!el)return;
  var d=el.dataset;
  // FIX 5: Weather hourly click - check element and parents
  if(d.whourly!==undefined){showHourlyForecast(0);return;}
  if(d.wday!==undefined){showHourlyForecast(parseInt(d.wday));return;}
  // Also check parent elements for weather click
  var weatherEl=el.closest('[data-whourly]');
  if(weatherEl){showHourlyForecast(0);return;}
  var wdayEl=el.closest('[data-wday]');
  if(wdayEl){showHourlyForecast(parseInt(wdayEl.dataset.wday));return;}
  // News card interactions
  if(d.bm!==undefined){e.stopPropagation();togBM(el,parseInt(d.bm));return;}
  if(d.share!==undefined){e.stopPropagation();shareArt(parseInt(d.share));return;}
  if(d.tts!==undefined){e.stopPropagation();var n=newsData[parseInt(d.tts)];if(n)speak(n.title+'. '+n.desc);return;}
  if(d.copy!==undefined){e.stopPropagation();copyNews(parseInt(d.copy));return;}
  if(d.sum!==undefined){e.stopPropagation();showSummary(el,parseInt(d.sum));return;}
  if(d.src!==undefined){e.stopPropagation();var n2=newsData[parseInt(d.src)];if(n2)window.open(n2.link,'_blank');return;}
  if(d.ftag){filterTag(d.ftag);return;}
  if(d.cleartag){clearTag();return;}
  if(d.nlang){S.newsLang=d.nlang;localStorage.setItem('newsLang',d.nlang);renderNews(S.subSection||'rajasthan');return;}
  if(d.rnews){renderNews(d.rnews);return;}
  if(d.srcfilter){S.activeSource=d.srcfilter;renderNews(S.subSection||'rajasthan');return;}
  if(d.alang){setAppLang(d.alang);return;}
  if(d.nlangset){S.newsLang=d.nlangset;localStorage.setItem('newsLang',d.nlangset);renderSettings();return;}
  if(d.tgl){var key=d.tgl;if(key==='dark'){S.dark=!S.dark;document.documentElement.setAttribute('data-theme',S.dark?'dark':'light');localStorage.setItem('dark',S.dark);renderSettings();}else if(key==='autoTranslate'){S.autoTranslate=!S.autoTranslate;localStorage.setItem('autoTranslate',S.autoTranslate);renderSettings();}else{var tk='notif'+key.replace('notif','');S[tk]=!S[tk];localStorage.setItem(tk,S[tk]);if(S[tk]&&'Notification'in window){Notification.requestPermission();}renderSettings();}return;}
  if(d.gosection){closeMenu();go(d.gosection);return;}
  if(d.mhome){moveHome(d.mhome,parseInt(d.mdir));return;}
  if(d.qlang){S.quizLang=d.qlang;localStorage.setItem('quizLang',d.qlang);renderQuiz();return;}
  if(d.examcat){S.examCat=d.examcat;renderExamPrep();return;}
  if(d.factcat){S.factCat=d.factcat;renderFactCheck();return;}
  if(d.genpdf){generatePDF(d.genpdf);return;}
  // FIX 3: History translate toggle
  if(d.histtranslate!==undefined){toggleHistoryLang();return;}
  // News card expand
  var nc=el.closest('.nc');
  if(nc&&nc.dataset.nid&&!d.bm&&!d.share&&!d.tts&&!d.copy&&!d.sum&&!d.src&&!d.ftag&&!d.cleartag){toggleExpand(parseInt(nc.dataset.nid));return;}
});
document.addEventListener('change',function(e){if(e.target&&e.target.id==='areaSelect'){S.myArea=e.target.value;localStorage.setItem('myArea',e.target.value);renderSettings();}if(e.target&&e.target.dataset&&e.target.dataset.srcfilter){S.activeSource=e.target.value;renderNews(S.subSection||'rajasthan');}});

// RENDER HOME
function renderHome(){
  document.getElementById('content').innerHTML='<div class="rfr-bar"><span class="rfr-time">'+(S.lastR?S.lastR.toLocaleTimeString('hi-IN'):'⏳ '+T('loading'))+'</span><button class="rfr-btn" onclick="loadAll()">🔄 '+T('refresh')+'</button></div><div class="wb" id="wBox" style="cursor:pointer">⏳ '+T('loading')+'</div><div class="s-title">📄 '+T('pdfDownload')+'</div><div class="pd-box"><div class="pd-row"><span class="pd-label">'+T('pdfDownload')+'</span><span class="pd-val" id="pdfStatusTxt">'+T('pdfNotSaved')+'</span></div><button class="pdf-btn" onclick="downloadPDF()">'+T('pdfGenerate')+'</button></div><div class="s-title">📰 '+T('todayNews')+'</div><div id="hNews"><div class="loading">⏳ '+T('loading')+'</div></div><div style="margin-top:10px">'+TAGS.slice(0,8).map(function(t){return '<span class="nc-tag hi" data-ftag="'+t+'">'+t+'</span>';}).join('')+'</div>';
  fetchWeather();loadHNews();updatePDFStatus();
}
async function loadHNews(){var all=[];var langs=S.newsLang==='both'?['hi','en']:[S.newsLang==='hi'?'hi':'en'];for(var li=0;li<langs.length;li++){for(var ki=0;ki<S.homeOrder.length;ki++){var ck=langs[li]+'_'+S.homeOrder[ki];if(!S.cache[ck]){await fetchRSSByLang(langs[li],S.homeOrder[ki]);}if(S.cache[ck])all.push.apply(all,S.cache[ck].slice(0,4));}}all.sort(function(a,b){return new Date(b.pubDate)-new Date(a.pubDate);});var c=document.getElementById('hNews');if(!all.length){c.innerHTML='<div class="empty"><div class="ei">📡</div>'+T('noNews')+'</div>';return;}var html='';for(var i=0;i<Math.min(all.length,40);i++){html+=ncHTML(all[i]);}c.innerHTML=html;document.getElementById('ticker').innerHTML='📰 '+all.slice(0,10).map(function(n){return n.title;}).join(' • ');}

// RENDER NEWS with source filter
async function renderNews(sub){if(!sub)sub='rajasthan';S.subSection=sub;var L=S.appLang;var lt='<div class="sub-tabs"><div class="sub-tab '+(S.newsLang==='hi'?'active':'')+'" data-nlang="hi">🇮🇳 हिंदी</div><div class="sub-tab '+(S.newsLang==='en'?'active':'')+'" data-nlang="en">🇬🇧 English</div><div class="sub-tab '+(S.newsLang==='both'?'active':'')+'" data-nlang="both">🌐 '+T('both')+'</div></div>';var st='<div class="sub-tabs">';NEWS_SECTIONS.forEach(function(s){st+='<div class="sub-tab '+(sub===s.key?'active':'')+'" data-rnews="'+s.key+'">'+(L==='hi'?s.hi:s.en)+'</div>';});st+='</div>';var srcOpts=ALL_SOURCES.map(function(s){return '<option value="'+s+'" '+(S.activeSource===s?'selected':'')+'>'+s+'</option>';}).join('');var srcFilter='<div style="margin-bottom:8px"><select class="sel-box" style="font-size:12px;padding:4px" data-srcfilter><option value="all">'+T('allSources')+'</option>'+srcOpts+'</select></div>';var tf=S.activeTag?'<div style="margin-bottom:8px"><span class="nc-tag hi" data-cleartag="1">✕ '+S.activeTag+'</span></div>':'';document.getElementById('content').innerHTML=lt+st+srcFilter+tf+'<div id="nContent"><div class="loading">⏳ '+sub+'...</div></div>';var langs=S.newsLang==='both'?['hi','en']:[S.newsLang==='hi'?'hi':'en'];var all=[];for(var i=0;i<langs.length;i++){var ck=langs[i]+'_'+sub;if(!S.cache[ck]){await fetchRSSByLang(langs[i],sub);}if(S.cache[ck])all.push.apply(all,S.cache[ck]);}if(S.activeTag)all=all.filter(function(n){return(n.title+n.desc).indexOf(S.activeTag)>=0;});if(S.activeSource!=='all')all=all.filter(function(n){return n.source===S.activeSource;});all.sort(function(a,b){return new Date(b.pubDate)-new Date(a.pubDate);});var nc=document.getElementById('nContent');nc.innerHTML=all.length?all.map(function(n){return ncHTML(n);}).join(''):'<div class="empty"><div class="ei">📡</div>'+T('noNews')+'</div>';}

// RENDER QUIZ
function renderQuiz(){S.score=0;var L=S.quizLang;var langToggle='<div class="sub-tabs"><div class="sub-tab '+(L==='hi'?'active':'')+'" data-qlang="hi">🇮🇳 हिंदी</div><div class="sub-tab '+(L==='en'?'active':'')+'" data-qlang="en">🇬🇧 English</div></div>';document.getElementById('content').innerHTML=langToggle+'<div class="qz-score" id="qScore">🏆 '+T('score')+': 0/'+QUIZ.length+'</div><div class="s-title">❓ GK Quiz</div><div id="qList">'+QUIZ.map(function(q,i){return '<div class="qz-q" id="qq'+i+'"><div class="qz-text"><b>Q'+(i+1)+':</b> '+q.q[L]+'</div>'+q.o[L].map(function(o,j){return '<button class="qz-opt" onclick="ansQ('+i+','+j+','+q.a+')">'+o+'</button>';}).join('')+'</div>';}).join('')+'</div>';}
function ansQ(qi,oi,ci){if(S.answered.indexOf(qi)>=0)return;S.answered.push(qi);localStorage.setItem('qa',JSON.stringify(S.answered));var q=document.getElementById('qq'+qi),opts=q.querySelectorAll('.qz-opt');opts[ci].classList.add('correct');if(oi!==ci)opts[oi].classList.add('wrong');if(oi===ci)S.score++;q.style.opacity='.5';document.getElementById('qScore').innerHTML='🏆 '+T('score')+': '+S.score+'/'+QUIZ.length;}

// VOCAB
var vocabIdx=0;
function renderVocab(){document.getElementById('content').innerHTML='<div class="s-title">🔤 Vocabulary</div><div id="vocabCard"></div><div style="display:flex;justify-content:space-between;margin-top:10px"><button class="rfr-btn" onclick="prevVocab()">⬅️</button><span id="vocabCount" style="font-size:13px;color:var(--muted);padding-top:6px"></span><button class="rfr-btn" onclick="nextVocab()">➡️</button></div>';showVocabCard();}
function showVocabCard(){var w=VOCAB[vocabIdx];document.getElementById('vocabCard').innerHTML='<div class="vc" onclick="flipVocab(this)"><div class="vc-eng">'+w.e+'</div><div class="vc-hint">'+(S.appLang==='hi'?'👆 हिंदी देखो':'👆 Tap for Hindi')+'</div></div>';document.getElementById('vocabCount').textContent=(vocabIdx+1)+' / '+VOCAB.length;}
function flipVocab(el){var w=VOCAB[vocabIdx];if(el.querySelector('.vc-hin'))el.innerHTML='<div class="vc-eng">'+w.e+'</div><div class="vc-hint">'+(S.appLang==='hi'?'👆 हिंदी देखो':'👆 Tap for Hindi')+'</div>';else el.innerHTML='<div class="vc-hin">'+w.h+'</div><div class="vc-hint">'+(S.appLang==='hi'?'👆 वापस':'👆 Back')+'</div>';}
function nextVocab(){vocabIdx=(vocabIdx+1)%VOCAB.length;showVocabCard();}
function prevVocab(){vocabIdx=(vocabIdx-1+VOCAB.length)%VOCAB.length;showVocabCard();}

// FIX 2: PANCHANG with govt holiday styling
function renderPanchang(){var L=S.appLang;var ms=L==='hi'?['जनवरी','फरवरी','मार्च','अप्रैल','मई','जून','जुलाई','अगस्त','सितंबर','अक्टूबर','नवंबर','दिसंबर']:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];var dn=L==='hi'?['रवि','सोम','मंगल','बुध','गुरु','शुक्र','शनि']:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];var y=S.panYear,m=S.panMonth,fd=new Date(y,m,1).getDay(),dim=new Date(y,m+1,0).getDate(),today=new Date();var h='<div class="s-title">🌙 '+(L==='hi'?'हिंदू पंचांग':'Panchang')+'</div>';var holCount=0;h+='<div class="pan-legend"><span class="pan-legend-item" style="background:#ffebee;border:1px solid #c62828">🔴 गव्ट अवकाश</span><span class="pan-legend-item" style="background:#fff8e1;border:1px solid #f9a825">🟡 विशेष दिवस</span><span class="pan-legend-item" style="background:#e8f5e9;border:1px solid #2e7d32">🟢 आज</span></div>';h+='<div class="pcal-nav"><button class="pcal-btn" onclick="panNav(-1)">⬅️</button><span class="pcal-month">'+ms[m]+' '+y+'</span><button class="pcal-btn" onclick="panNav(1)">➡️</button></div><div class="pcal">';dn.forEach(function(d){h+='<div class="pcal-dn">'+d+'</div>';});for(var i=0;i<fd;i++)h+='<div class="pcal-day empty"></div>';for(var dd=1;dd<=dim;dd++){var date=new Date(y,m,dd),phase=getMoonPhase(date),tithi=getTithi(phase),holKey=(m+1)+'-'+dd,ghol=GOVT_HOLIDAYS[holKey],sp=SPECIAL_DAYS[holKey],isToday=dd===today.getDate()&&m===today.getMonth()&&y===today.getFullYear();var spHTML='';if(sp){spHTML='<div class="pcal-special">'+sp[0].i+' '+sp[0].n+'</div>';}var holHTML='';if(ghol){holHTML='<div class="pcal-ghol">🔴 '+ghol.name+'</div>';holCount++;}var dayClass='pcal-day';if(isToday)dayClass+=' today';if(ghol)dayClass+=' govt-hol';else if(sp)dayClass+=' spec-hol';h+='<div class="'+dayClass+'" onclick="panDayClick('+dd+','+m+','+y+')"><div class="pcal-date">'+dd+'</div>'+moonSVG(phase)+'<div class="pcal-tithi">'+tithi.name+'</div>'+holHTML+spHTML+'</div>';}h+='</div><div style="margin-top:8px"><button class="rfr-btn" onclick="panToday()">'+T('today')+'</button></div><div id="panDetails"></div>';document.getElementById('content').innerHTML=h;}
function panNav(d){S.panMonth+=d;if(S.panMonth<0){S.panMonth=11;S.panYear--;}if(S.panMonth>11){S.panMonth=0;S.panYear++;}renderPanchang();}
function panToday(){var d=new Date();S.panMonth=d.getMonth();S.panYear=d.getFullYear();renderPanchang();panDayClick(d.getDate(),d.getMonth(),d.getFullYear());}
function panDayClick(dd,m,y){var date=new Date(y,m,dd),phase=getMoonPhase(date),tithi=getTithi(phase),nakshatra=getNakshatra(date),holKey=(m+1)+'-'+dd,ghol=GOVT_HOLIDAYS[holKey],sp=SPECIAL_DAYS[holKey];var dn=S.appLang==='hi'?['रविवार','सोमवार','मंगलवार','बुधवार','गुरुवार','शुक्रवार','शनिवार']:['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];var ms=S.appLang==='hi'?['जनवरी','फरवरी','मार्च','अप्रैल','मई','जून','जुलाई','अगस्त','सितंबर','अक्टूबर','नवंबर','दिसंबर']:['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];var pk=tithi.paksha==='shukla'?'शुक्ल पक्ष':'कृष्ण पक्ष';var moonDesc=phase<0.02||phase>0.98?'अमावस्या':Math.abs(phase-0.5)<0.02?'पूर्णिमा':Math.round(phase<0.5?phase*200:(1-phase)*200)+'% दृश्य';var h='<div class="s-title" style="margin-top:14px">📅 '+dn[date.getDay()]+', '+dd+' '+ms[m]+' '+y+'</div><div style="text-align:center;margin:10px 0">'+moonSVG(phase)+'<div style="font-size:13px;margin-top:4px">'+(tithi.paksha==='shukla'?'🌙 शुक्ल':'🌙 कृष्ण')+'</div></div><div class="pd-box"><div class="pd-row"><span class="pd-label">तिथि</span><span class="pd-val">'+tithi.name+' ('+pk+')</span></div><div class="pd-row"><span class="pd-label">वार</span><span class="pd-val">'+dn[date.getDay()]+'</span></div><div class="pd-row"><span class="pd-label">नक्षत्र</span><span class="pd-val">'+nakshatra+'</span></div><div class="pd-row"><span class="pd-label">चंद्रमा</span><span class="pd-val">'+moonDesc+'</span></div><div class="pd-row"><span class="pd-label">सूर्योदय</span><span class="pd-val">6:12 AM</span></div><div class="pd-row"><span class="pd-label">सूर्यास्त</span><span class="pd-val">6:35 PM</span></div></div>';if(ghol)h+='<div class="pd-ghol-big">🔴 '+ghol.name+' — '+T('holiday')+'</div>';if(sp){sp.forEach(function(s){h+='<div class="pd-hol">'+s.i+' '+s.n+'</div>';});}h+='<div class="s-title" style="margin-top:14px">📜 '+(S.appLang==='hi'?'आज का इतिहास':'On This Day')+'</div><div class="pd-box" id="panHistory"><div class="loading">⏳ '+T('loading')+'</div></div>';document.getElementById('panDetails').innerHTML=h;fetchHistory(dd,m+1);}

// FIX 3: History - Hindi first, working translate toggle
function fetchHistory(dd,mm){
  S.historyData=[];
  S.historyLang='hi';
  var hiUrl='https://hi.wikipedia.org/api/rest_v1/feed/onthisday/events/'+mm+'/'+dd;
  fetch(hiUrl).then(function(r){return r.json()}).then(function(d){
    var events=(d.events||[]).slice(0,10);
    if(events.length){
      S.historyData=events;
      S.historyLang='hi';
      displayHistory();
    }else{
      // Fallback to English
      var enUrl='https://en.wikipedia.org/api/rest_v1/feed/onthisday/events/'+mm+'/'+dd;
      fetch(enUrl).then(function(r2){return r2.json()}).then(function(d2){
        var ev=(d2.events||[]).slice(0,10);
        S.historyData=ev;
        S.historyLang='en';
        displayHistory();
      }).catch(function(){displayHistoryError();});
    }
  }).catch(function(){displayHistoryError();});
}
function displayHistoryError(){var box=document.getElementById('panHistory');if(box)box.innerHTML='<div style="font-size:13px;color:var(--muted)">'+(S.appLang==='hi'?'इतिहास लोड नहीं हो सका':'Failed to load')+'</div>';}
function displayHistory(){
  var box=document.getElementById('panHistory');
  if(!box)return;
  if(!S.historyData.length){box.innerHTML='<div style="font-size:13px;color:var(--muted)">'+(S.appLang==='hi'?'कोई घटना नहीं':'No events')+'</div>';return;}
  var isHindi=S.historyLang==='hi';
  var toggleBtn='';
  if(!isHindi){
    // English content - show translate button
    toggleBtn='<button class="hist-translate-btn" data-histtranslate="1">🌐 '+T('translated')+' (Hindi में देखो)</button>';
  }else{
    toggleBtn='<div class="hist-lang-badge">🇮🇳 Hindi</div>';
  }
  var html=toggleBtn;
  if(!isHindi&&S.historyTranslated){
    // Show translated (simple: just show with note)
    S.historyData.forEach(function(e){
      html+='<div class="hist-event"><b>'+(e.year||'')+'</b>: '+(e.text||'').substring(0,150)+'</div>';
    });
    html='<div class="hist-lang-badge">🌐 अनुवादित</div>';
    S.historyData.forEach(function(e){
      html+='<div class="hist-event"><b>'+(e.year||'')+'</b>: '+(e.text||'').substring(0,150)+'</div>';
    });
  }else{
    S.historyData.forEach(function(e){
      html+='<div class="hist-event"><b>'+(e.year||'')+'</b>: '+(e.text||'').substring(0,150)+'</div>';
    });
  }
  box.innerHTML=html;
}
function toggleHistoryLang(){
  if(S.historyLang==='en'){
    S.historyTranslated=!S.historyTranslated;
    displayHistory();
  }
}

// KIDS
function renderKids(){document.getElementById('content').innerHTML='<div class="s-title">🧒 '+T('kidsCorner')+'</div>'+KIDS.map(function(k){var ic=k.type==='story'?'📖':k.type==='science'?'🔬':k.type==='history'?'📜':k.type==='quiz'?'❓':'🔤';return '<div class="kid-card"><div class="kid-title">'+ic+' '+k.title+'</div><div class="kid-content">'+k.content+'</div><div class="kid-meta">🔗 '+k.src+' • ✅ '+T('verified')+'</div></div>';}).join('');}

// EXAM
function renderExamPrep(){S.examCat=S.examCat||'all';var cats=['all','RPSC','Patwari','REET'];var catFilter='<div class="sub-tabs">';cats.forEach(function(c){catFilter+='<div class="sub-tab '+(S.examCat===c?'active':'')+'" data-examcat="'+c+'">'+(c==='all'?(S.appLang==='hi'?'सभी':'All'):c)+'</div>';});catFilter+='</div>';var qs=S.examCat==='all'?EXAM:EXAM.filter(function(q){return q.cat===S.examCat;});document.getElementById('content').innerHTML=catFilter+'<div class="s-title">📝 '+T('examPrep')+'</div><div style="font-size:12px;color:var(--muted);margin-bottom:8px">'+qs.length+' '+(S.appLang==='hi'?'प्रश्न':'Questions')+'</div>'+qs.map(function(q,i){return '<div class="exam-card" id="ex'+i+'"><div class="exam-q"><b>Q'+(i+1)+':</b> '+q.q+' <span style="font-size:10px;color:#1565c0">['+q.cat+']</span></div>'+q.o.map(function(o,j){return '<button class="exam-opt" onclick="ansExam('+i+','+j+','+q.a+')">'+o+'</button>';}).join('')+'</div>';}).join('')+'<div style="margin-top:10px;font-size:12px;color:var(--muted)">✅ '+T('verified')+'</div>';}
function ansExam(qi,oi,ci){var q=document.getElementById('ex'+qi),opts=q.querySelectorAll('.exam-opt');opts[ci].classList.add('correct');if(oi!==ci)opts[oi].classList.add('wrong');q.style.opacity='.5';showToast(oi===ci?'✅ '+T('correct'):'❌ '+T('wrong'));}

// FACT CHECK
function renderFactCheck(){S.factCat=S.factCat||'all';var cats=['all','viral','govt','health'];var catFilter='<div class="sub-tabs">';var catLabels={all:(S.appLang==='hi'?'सभी':'All'),viral:(S.appLang==='hi'?'वायरल':'Viral'),govt:(S.appLang==='hi'?'सरकारी':'Govt'),health:(S.appLang==='hi'?'स्वास्थ्य':'Health')};cats.forEach(function(c){catFilter+='<div class="sub-tab '+(S.factCat===c?'active':'')+'" data-factcat="'+c+'">'+catLabels[c]+'</div>';});catFilter+='</div>';var fs=S.factCat==='all'?FACTS:FACTS.filter(function(f){return f.cat===S.factCat;});document.getElementById('content').innerHTML=catFilter+'<div class="s-title">✅ '+T('factCheck')+'</div><div class="fc-form"><textarea class="fc-input" id="fcInput" rows="3" placeholder="'+(S.appLang==='hi'?'वायरल मैसेज पेस्ट करें...':'Paste message...')+'"></textarea><button class="fc-btn" onclick="checkFact()">'+(S.appLang==='hi'?'जाँच करो':'Check')+'</button><div id="fcResult"></div></div><div class="s-title" style="margin-top:14px">📋 '+(S.appLang==='hi'?'सत्यापित दावे':'Verified Claims')+' ('+fs.length+')</div>'+fs.map(function(f){var v=f.verdict==='true'?'✅ सच':f.verdict==='false'?'❌ फ़र्ज़ी':'⚠️ अधूरा';var cls=f.verdict==='true'?'true':f.verdict==='false'?'false':'mixed';return '<div class="fc-item"><div class="fc-claim">'+f.claim+'</div><div class="fc-verdict fc-result '+cls+'">'+v+' — '+f.text+'</div><div class="nc-meta"><span>🔗 '+f.src+'</span> • <span class="nc-verified">✅ '+T('verified')+'</span></div></div>';}).join('');}
function checkFact(){var input=document.getElementById('fcInput').value.trim();if(!input){showToast('कुछ लिखें');return;}document.getElementById('fcResult').innerHTML='<div class="fc-result mixed">⚠️ '+(S.appLang==='hi'?'जाँच रहा है... PIB Fact Check, Alt News, BoomLive पर जाँच करें।':'Check PIB, Alt News, BoomLive.')+'</div>';}

// ARCHIVE
function renderArchive(){var d=new Date(),y=d.getFullYear(),m=d.getMonth(),fd=new Date(y,m,1).getDay(),dim=new Date(y,m+1,0).getDate();var dn=S.appLang==='hi'?['र','सो','मं','बु','गु','शु','श']:['S','M','T','W','T','F','S'];var h='<div class="s-title">📅 '+T('archive')+'</div><div class="arc-grid">';dn.forEach(function(x){h+='<div class="pcal-dn">'+x+'</div>';});for(var i=0;i<fd;i++)h+='<div class="arc-day empty"></div>';for(var dd=1;dd<=dim;dd++){var today=dd===d.getDate(),has=dd<=d.getDate();h+='<div class="arc-day'+(has?' has':'')+(today?' today':'')+'" '+(has?'onclick="openArc('+dd+','+(m+1)+','+y+')"':'')+'>'+dd+'</div>';}h+='</div><div id="arcDetails"></div>';document.getElementById('content').innerHTML=h;}
function openArc(dd,mm,yy){var dateKey=yy+'-'+String(mm).padStart(2,'0')+'-'+String(dd).padStart(2,'0');var status=S.pdfStatus[dateKey]||'none';var statusText=status==='ready'?'✅ '+T('pdfReady'):status==='generating'?'⏳ '+T('pdfGenerating'):T('pdfNotSaved');var btnText=status==='ready'?T('pdfDownload'):T('pdfCreate');var btnAction=status==='ready'?'downloadPDF()':'generatePDF("'+dateKey+'")';document.getElementById('arcDetails').innerHTML='<div class="s-title" style="margin-top:14px">📅 '+dd+'/'+mm+'/'+yy+'</div><div class="pd-box"><div class="pd-row"><span class="pd-label">'+(S.appLang==='hi'?'स्थिति':'Status')+'</span><span class="pd-val" id="arcStatus">'+statusText+'</span></div></div><button class="pdf-btn" onclick="'+btnAction+'">'+btnText+'</button>';}

// BOOKMARKS
function renderBookmarks(){var c=document.getElementById('content');if(!S.bm.length){c.innerHTML='<div class="empty"><div class="ei">⭐</div>'+T('noBm')+'</div>';return;}c.innerHTML='<div class="s-title">⭐ '+T('bookmarks')+'</div>'+S.bm.map(function(b,i){return '<div class="nc"><div class="nc-title">'+b.title+'</div><div class="nc-meta"><span>'+new Date(b.date).toLocaleDateString('hi-IN')+'</span></div><span class="nc-bm on" onclick="rmBM('+i+')">🗑️</span></div>';}).join('');}
function rmBM(i){S.bm.splice(i,1);localStorage.setItem('bm',JSON.stringify(S.bm));renderBookmarks();}

// DISCLAIMER
function renderDisclaimer(){document.getElementById('content').innerHTML='<div class="s-title">📋 '+T('disclaimer')+'</div><div class="disclaimer-box"><h3>⚠️ Legal Disclaimer & Terms of Use</h3><p><b>Last Updated:</b> 8 September 2026</p><br><p>This web application, including all content, news articles, educational materials, quizzes, weather data, panchang information, and other features (collectively, the Content), is published in good faith and is intended solely for <b>general informational and educational purposes</b> in compliance with the following Indian laws:</p><br><p>1. <b>Information Technology Act, 2000 (IT Act)</b> and the Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules, 2021.</p><br><p>2. <b>Bharatiya Nyaya Sanhita, 2023 (BNS)</b> and <b>Bharatiya Nagarik Suraksha Sanhita, 2023 (BNSS)</b>.</p><br><p>3. <b>Consumer Protection Act, 2019</b>.</p><br><p>4. <b>Copyright Act, 1957</b> - all third-party content is attributed to its original source with clickable source links.</p><br><p><b>Educational Purpose Declaration:</b> The Content is prepared strictly for educational and informational purposes only. It is not professional advice. Users should independently verify all information.</p><br><p><b>News Aggregation:</b> This app aggregates news from publicly available RSS feeds (Google News, BBC Hindi, The Hindu, Indian Express, NDTV, etc.) and provides clickable source links. All content belongs to respective publishers. If any content owner has objection, they may submit a removal request via Feedback.</p><br><p><b>Accuracy:</b> While efforts are made to ensure accuracy, no guarantee is provided regarding completeness or reliability.</p><br><p><b>Limitation of Liability:</b> The developer shall not be liable for any damages arising from the use of this application.</p><br><p><b>Feedback & Grievance Redressal:</b> Objections may be submitted through the Feedback option. Appropriate action will be taken within a reasonable time frame per Rule 3 of IT (Intermediary Guidelines) Rules.</p><br><p><b>Jurisdiction:</b> This application operates from India and is subject to Indian courts jurisdiction.</p></div>';}

// FEEDBACK
function renderFeedback(){document.getElementById('content').innerHTML='<div class="s-title">💬 '+T('feedback')+'</div><div class="feedback-form"><p style="font-size:13px;color:var(--muted);margin-bottom:10px">'+(S.appLang==='hi'?'आपत्ति, सुझाव या शिकायत के लिए यहाँ लिखें।':'Write your feedback here.')+'</p><input type="text" class="fb-input" id="fbName" placeholder="'+(S.appLang==='hi'?'नाम':'Name')+'"><select class="fb-input" id="fbType"><option value="complaint">'+(S.appLang==='hi'?'शिकायत':'Complaint')+'</option><option value="suggestion">'+(S.appLang==='hi'?'सुझाव':'Suggestion')+'</option><option value="removal">Content Removal Request</option><option value="bug">Bug Report</option></select><textarea class="fb-input" id="fbMessage" rows="4" placeholder="'+(S.appLang==='hi'?'विस्तार से...':'In detail...')+'"></textarea><button class="fc-btn" onclick="submitFeedback()">'+(S.appLang==='hi'?'सबमिट':'Submit')+'</button><div id="fbResult"></div></div><div style="font-size:12px;color:var(--muted);margin-top:10px">📋 <span style="color:var(--accent);cursor:pointer;text-decoration:underline" data-gosection="disclaimer">'+(S.appLang==='hi'?'डिस्क्लेमर पढ़ें':'Read Disclaimer')+'</span></div>';}
function submitFeedback(){var name=document.getElementById('fbName').value.trim();var msg=document.getElementById('fbMessage').value.trim();if(!msg){showToast('संदेश लिखें');return;}var type=document.getElementById('fbType').value;var fb=JSON.parse(localStorage.getItem('feedbacks')||'[]');fb.push({name:name,type:type,msg:msg,date:new Date().toISOString()});localStorage.setItem('feedbacks',JSON.stringify(fb));document.getElementById('fbResult').innerHTML='<div class="fc-result true">✅ '+T('feedback')+' ✓</div>';document.getElementById('fbName').value='';document.getElementById('fbMessage').value='';showToast('✅ ✓');}

// SETTINGS
function renderSettings(){var L=S.appLang;var opts=Object.keys(AREAS).map(function(k){return '<option value="'+k+'" '+(S.myArea===k?'selected':'')+'>'+(L==='hi'?AREAS[k].hi:AREAS[k].en)+'</option>';}).join('');document.getElementById('content').innerHTML='<div class="s-title">⚙️ '+T('settings')+'</div><div class="settings-box"><div class="set-row"><span class="set-label">🌐 '+T('appLang')+'</span><div><button class="lang-btn '+(S.appLang==='hi'?'active':'')+'" data-alang="hi">हिंदी</button><button class="lang-btn '+(S.appLang==='en'?'active':'')+'" data-alang="en">English</button></div></div><div class="set-row"><span class="set-label">📰 '+T('newsLang')+'</span><div><button class="lang-btn '+(S.newsLang==='hi'?'active':'')+'" data-nlangset="hi">🇮🇳 हिंदी</button><button class="lang-btn '+(S.newsLang==='en'?'active':'')+'" data-nlangset="en">🇬🇧 English</button><button class="lang-btn '+(S.newsLang==='both'?'active':'')+'" data-nlangset="both">🌐 '+T('both')+'</button></div></div><div class="set-row"><span class="set-label">🔄 '+T('autoTranslate')+'</span><div class="toggle '+(S.autoTranslate?'on':'')+'" data-tgl="autoTranslate"><div class="knob"></div></div></div><div class="set-row"><span class="set-label">🔔 '+T('daily')+'</span><div class="toggle '+(S.notifDaily?'on':'')+'" data-tgl="notifDaily"><div class="knob"></div></div></div><div class="set-row"><span class="set-label">📖 '+T('wordOfDay')+'</span><div class="toggle '+(S.notifWord?'on':'')+'" data-tgl="notifWord"><div class="knob"></div></div></div><div class="set-row"><span class="set-label">🌙 '+T('darkMode')+'</span><div class="toggle '+(S.dark?'on':'')+'" data-tgl="dark"><div class="knob"></div></div></div><div class="set-row"><span class="set-label">📍 '+T('location')+'</span><select class="sel-box" id="areaSelect">'+opts+'</select></div></div>';}
function setAppLang(l){S.appLang=l;localStorage.setItem('appLang',l);document.getElementById('appTitle').textContent='राजस्थान समाचार';var nm={Home:'home',News:'news',Quiz:'quiz',Pan:'panchang',More:'more'};Object.keys(nm).forEach(function(k){var el=document.getElementById('nav'+k);if(el)el.textContent=T(nm[k]);});renderSettings();}

// MENU
function openMenu(){document.getElementById('menuOverlay').classList.add('show');document.getElementById('menuPanel').classList.add('show');var items=[{i:'⭐',l:T('bookmarks'),a:'bookmarks'},{i:'🔤',l:T('vocab'),a:'vocab'},{i:'🧒',l:T('kidsCorner'),a:'kids'},{i:'📝',l:T('examPrep'),a:'exam'},{i:'✅',l:T('factCheck'),a:'factcheck'},{i:'📅',l:T('archive'),a:'archive'},{i:'💬',l:T('feedback'),a:'feedback'},{i:'📋',l:T('disclaimer'),a:'disclaimer'},{i:'⚙️',l:T('settings'),a:'settings'}];document.getElementById('menuItems').innerHTML=items.map(function(it){return '<div class="menu-item" data-gosection="'+it.a+'"><span class="mi">'+it.i+'</span>'+it.l+'</div>';}).join('');}
function closeMenu(){document.getElementById('menuOverlay').classList.remove('show');document.getElementById('menuPanel').classList.remove('show');}

// CUSTOMIZE
function renderCustomize(){var L=S.appLang;document.getElementById('content').innerHTML='<div class="s-title">🏠 '+T('customize')+'</div>'+NEWS_SECTIONS.map(function(s){return '<div class="customize-item"><span class="ci-name">'+(L==='hi'?s.hi:s.en)+'</span><div class="ci-btns"><button class="ci-btn" data-mhome="'+s.key+'" data-mdir="-1">↑</button><button class="ci-btn" data-mhome="'+s.key+'" data-mdir="1">↓</button></div></div>';}).join('');}
function moveHome(key,dir){var idx=S.homeOrder.indexOf(key);if(idx<0){S.homeOrder.push(key);idx=S.homeOrder.length-1;}var ni=idx+dir;if(ni<0||ni>=S.homeOrder.length)return;var tmp=S.homeOrder[idx];S.homeOrder[idx]=S.homeOrder[ni];S.homeOrder[ni]=tmp;localStorage.setItem('homeOrder',JSON.stringify(S.homeOrder));renderCustomize();}

// NAV
function go(section){S.section=section;document.querySelectorAll('.nav-btn').forEach(function(b){b.classList.remove('active');});var btn=document.querySelector('[data-s="'+section+'"]');if(btn)btn.classList.add('active');if(section==='home')renderHome();else if(section==='news')renderNews('rajasthan');else if(section==='quiz')renderQuiz();else if(section==='panchang')renderPanchang();else if(section==='settings')renderSettings();else if(section==='bookmarks')renderBookmarks();else if(section==='vocab')renderVocab();else if(section==='kids')renderKids();else if(section==='exam')renderExamPrep();else if(section==='factcheck')renderFactCheck();else if(section==='archive')renderArchive();else if(section==='customize')renderCustomize();else if(section==='disclaimer')renderDisclaimer();else if(section==='feedback')renderFeedback();window.scrollTo(0,0);}
function toggleDark(){S.dark=!S.dark;document.documentElement.setAttribute('data-theme',S.dark?'dark':'light');localStorage.setItem('dark',S.dark);}
function fontSz(d){S.fs=Math.max(12,Math.min(24,S.fs+d));document.documentElement.style.setProperty('--fs',S.fs+'px');localStorage.setItem('fs',S.fs);}

// INIT
function init(){if(S.dark)document.documentElement.setAttribute('data-theme','dark');document.documentElement.style.setProperty('--fs',S.fs+'px');document.getElementById('appTitle').textContent='राजस्थान समाचार';var nm={Home:'home',News:'news',Quiz:'quiz',Pan:'panchang',More:'more'};Object.keys(nm).forEach(function(k){var el=document.getElementById('nav'+k);if(el)el.textContent=T(nm[k]);});var d=new Date(),ds=['रवि','सोम','मंगल','बुध','गुरु','शुक्र','शनि'],ms=['जन','फर','मार्च','अप्रैल','मई','जून','जुलाई','अग','सित','अक्टू','नव','दिस'];document.getElementById('dateBar').textContent=ds[d.getDay()]+', '+d.getDate()+' '+ms[d.getMonth()]+' '+d.getFullYear();updateConn();go('home');loadAll();setInterval(function(){if(navigator.onLine&&document.visibilityState==='visible')loadAll();},300000);}

// SEARCH
function toggleSearch(){var sb=document.getElementById('searchBox');if(sb.style.display==='none'){sb.style.display='block';var sr=document.getElementById('searchRecent');if(S.recentSearch.length){sr.style.display='block';sr.className='search-recent';sr.innerHTML='<div style="margin-bottom:4px">'+T('recentSearch')+':</div>'+S.recentSearch.slice(-5).map(function(q){return '<span class="search-chip" onclick="document.getElementById(\'searchInput\').value=\''+q+'\';doSearch(\''+q+'\')">'+q+'</span>';}).join('');}document.getElementById('searchInput').focus();}else{sb.style.display='none';document.getElementById('searchInput').value='';go(S.section);}}
function doSearch(q){if(!q||q.length<2){if(!q)go(S.section);return;}if(S.recentSearch.indexOf(q)<0){S.recentSearch.push(q);if(S.recentSearch.length>10)S.recentSearch.shift();localStorage.setItem('rs',JSON.stringify(S.recentSearch));}var all=[];Object.keys(S.cache).forEach(function(k){all.push.apply(all,S.cache[k]);});var r=all.filter(function(n){return(n.title&&n.title.indexOf(q)>=0)||(n.desc&&n.desc.indexOf(q)>=0);});var c=document.getElementById('content');c.innerHTML=r.length?'<div class="s-title">🔍 "'+q+'" — '+r.length+'</div>'+r.map(function(n){return ncHTML(n);}).join(''):'<div class="empty"><div class="ei">🔍</div>"'+q+'" '+T('noResults')+'</div>';}

// PULL TO REFRESH
var tsY=0;document.addEventListener('touchstart',function(e){tsY=e.touches[0].clientY;});document.addEventListener('touchend',function(e){if(scrollY===0&&e.changedTouches[0].clientY>tsY+80)loadAll();});

// SW
if('serviceWorker'in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){});});}
init();
