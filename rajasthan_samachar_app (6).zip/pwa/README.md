# राजस्थान समाचार — PWA v4.1
## v4.1 Changes
1. **Source name fix**: Google News se aane wali news mein actual source extract hota hai (Bhaskar, BBC, TOI etc), "Google News" nahi dikhta
2. **Govt holidays**: Panchang mein govt holidays red background + border se, special days gold se
3. **On This Day**: Hindi pehle, English fallback mein translate button kaam karega
4. **PDF**: Proper newspaper-style HTML page (not app page) with all sections — Top News, Regional, Sports, Quiz, Exam, FactCheck, Vocab, Kids
5. **Weather click**: Hourly forecast properly khulta hai (12 hours, temp + icon + humidity)
## Deploy: upload zip to GitHub, Actions auto-deploy
