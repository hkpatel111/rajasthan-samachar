# राजस्थान समाचार — PWA v3.0

## v3.0 Changes
- Splash screen REMOVED — direct load
- Home page: NO quiz of the day (simplified)
- appTitle bug FIXED — direct text
- 25+ RSS sources (BBC Hindi, The Hindu, Indian Express, NDTV, Amar Ujala, TOI, etc.)
- Source filter dropdown in news
- News cards: source logo, image thumbnail, copy button, translate toggle
- Quiz: Hindi/English language toggle at top
- Panchang: Special Days (100+ days — Valentine week, national days, jayantis)
- Panchang: On This Day in Hindi (hi.wikipedia.org API)
- Exam prep: 60 questions (3x) with category filter (RPSC/Patwari/REET)
- Fact check: 15 claims (3x) with category filter (viral/govt/health)
- Archive: IndexedDB storage for cached PDFs
- Advanced search: section + date + source + sort
- Copy news text: clipboard API
- Disclaimer: IT Act, BNS, Consumer Protection Act, Copyright Act
- Feedback: complaint/suggestion/removal/bug form

## GitHub deploy
1. Create repo, add `.github/workflows/deploy.yml` (one-time, copy from zip)
2. Upload zip, commit
3. Settings > Pages > Source: GitHub Actions
4. URL: `https://<username>.github.io/rajasthan-samachar/`
