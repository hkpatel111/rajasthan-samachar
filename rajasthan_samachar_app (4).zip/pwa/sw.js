var CACHE_NAME = 'rajasthan-samachar-v3';
var ASSETS = ['./', './index.html', './manifest.json'];

self.addEventListener('install', function(e) {
  e.waitUntil(caches.open(CACHE_NAME).then(function(cache) {
    return cache.addAll(ASSETS).catch(function() {});
  }).then(function() { return self.skipWaiting(); }));
});

self.addEventListener('activate', function(e) {
  e.waitUntil(caches.keys().then(function(names) {
    return Promise.all(names.filter(function(n) { return n !== CACHE_NAME; }).map(function(n) { return caches.delete(n); }));
  }).then(function() { return self.clients.claim(); }));
});

self.addEventListener('fetch', function(e) {
  if (e.request.method !== 'GET') return;
  var url = new URL(e.request.url);
  if (url.origin !== self.location.origin) {
    e.respondWith(fetch(e.request).catch(function() { return caches.match(e.request); }));
    return;
  }
  e.respondWith(caches.match(e.request).then(function(cached) {
    var fp = fetch(e.request).then(function(r) {
      if (r && r.status === 200) { var c = r.clone(); caches.open(CACHE_NAME).then(function(cache) { cache.put(e.request, c); }); }
      return r;
    }).catch(function() { return cached; });
    return cached || fp;
  }));
});

self.addEventListener('notificationclick', function(e) {
  e.notification.close();
  e.waitUntil(clients.matchAll({ type: 'window' }).then(function(cl) {
    for (var i = 0; i < cl.length; i++) { if (cl[i].url.includes(self.location.origin) && 'focus' in cl[i]) return cl[i].focus(); }
    if (clients.openWindow) return clients.openWindow('./');
  }));
});
